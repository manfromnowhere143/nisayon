from pathlib import Path
import sys
from scope import read, write, environment, check_environment
from observer import load_native
from contract import run
ROOT = Path(__file__).resolve().parent
check_environment(environment(), read(ROOT / "contract.json")["environment"])
native = load_native(ROOT / "candidate")
CutmixGenerator, PatchMixGenerator, RandomCutMixV2 = native[1:]
def candidate(value):
    return run(value, native)
def reference(value):
    return run(value, native, reference=True)
if __name__ == "__main__":
    entry = {"reference": reference, "candidate": candidate}[sys.argv[1]]
    write(sys.argv[3], entry({"conditions": read(sys.argv[2])}))
