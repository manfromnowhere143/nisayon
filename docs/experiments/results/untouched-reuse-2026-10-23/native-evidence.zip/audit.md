# Native qualification audit

Final decision file: `report.json`. Final native evidence: `evidence-final/`.
The initial exploratory run in `evidence/` is retained in full and is superseded
by the reviewed final assessment. No supplied implementation was edited.

## Scope and identity

This is the authorized offline packet in the current writable workspace, not a
checkout of a sibling project. No local AGENTS.md or project handoff was present.
The initial `git rev-parse --show-toplevel` and `git remote -v` commands both
failed with `xcode-select: error: No developer tools were found and no install
could be requested`. No install or network operation was attempted. Source
identity instead uses the supplied seal, manifest, provenance, native import
paths and native file digests. Both native runs verified all 2,746 manifested
packet files before and after execution, without mismatches. The supplied venv
executable was invoked without resolving its symlink; Python binary hash,
version and all pinned distribution versions matched.

## Checks and interpretation

`qualify.py` uses the supplied unchanged `native_probe.py` observer. Each candidate
runs in its own interpreter, importing the full native Kornia package normally.
Every condition retains configuration, tensor dtype/shape/values, native call
counts, executed source-file hashes and any native exception. A standalone Beta
draw is attempted before the generator/module call: if configuration or that draw
fails, later operations in that condition are not executed. Those rows are
explicit failures, never counted as successful augmentation calls. The final
semantic checker requires actual generator forward and module image/class
transformation call witnesses for every successful condition.

The concentration oracle constructs both symmetric concentrations directly from
the original Python scalar in float32 for half dtypes and in the configured dtype
for float32/float64. It uses the pinned native PyTorch Beta with exactly the same
seed and checks dtype, shape and tensor equality. Geometry checks treat Kornia's
vertices as inclusive: end = start - 1 is an allowed empty interval. The image
oracle independently uses ordinary tensor slicing, never native bbox/mask helpers.
It copies each rectangle from the original source image and applies later mixes
last. Class-ID and lambda checks use original labels, selected pair indices and
integer rectangle area. Full-precision regression compares every retained output,
parameter and sampler observation against sealed candidate `c-1975d86b`, whose
provenance records the exact upstream base and whose local delta is empty.

The 16 supplied development examples are unchanged and all are executed for all
five candidates in both runs. The 72 additional cases per candidate cover both
concentration endpoints, 0.37 and 1.2345678901, all four dtypes, all three move
routes, sharing, multiple mixes, partial/full cut bounds, singleton images,
empty/full cuts and fitting patches. These are exposed development cases, not
reserved confirmation. Finite case coverage does not prove every possible input.

## Retained failed hypotheses and adaptation

1. Keeping half-precision Beta samplers, including a diagnostic-only comment,
   fails with native Half/BFloat16 Dirichlet exceptions. This rejects the base
   and the nonintervening diagnostic as repairs of this contract.
2. Promoting a previously half-rounded concentration does not preserve the
   scalar: 1e-8 underflows and raises, 100000 overflows to infinity, and 0.37
   rounds to 0.369140625 in bfloat16. Seeded draw mismatches are retained.
3. Always drawing in float32 avoids half errors but violates float64 precision
   and exact upstream-base regression. It fails 22 of 43 full-precision cases.
4. My initial singleton test assumed `cut_size=[0.999, 1]` stayed valid in every
   dtype. In bfloat16 it becomes `[1, 1]`, which the existing native validator
   rejects. The initial automatic report therefore incorrectly treated these
   input-policy observations as scoped violations. No supplied implementation or
   concentration acceptance rule was changed. The valid-cut-size matrix now uses
   exactly representable `[0.75, 1]`, which also forces a zero-sized singleton cut.
   All initial outputs, exceptions, checks and script bytes remain in `evidence/`.
   This is an explicit rejected test-design hypothesis; it is not silently erased.
   The two original bfloat16 conditions are in `rejected-hypothesis-inputs.json`.

Reproduce the excluded cut-bound observation, independently of the final matrix:

```sh
/Users/danielwahnich/workspace/nisayon-untouched-reuse-2026-10-23/artifacts/untouched-reuse-2026-10-23/evaluator-private/native-env/bin/python -B native_probe.py --candidate c-2ade37ec --inputs rejected-hypothesis-inputs.json --output rejected-hypothesis-replay.json
```

## Cost and stopping record

- Intake included reading the required task, candidates, procedure, environment,
  schema, rubric, public observations, source deltas, native implementations and
  relevant upstream test locations. One overbroad manifest display was truncated;
  subsequent verification parsed and hashed it without dumping its file list.
- One native trial ran 440 conditions in five candidate interpreters: 8.417 seconds
  including driver verification/checks. One test-case adaptation and witness-check
  strengthening followed. The final run repeated 440 conditions in five candidate
  interpreters: 8.615 seconds. Total: 880 native condition attempts, ten candidate
  processes, two drivers, about 17.031 seconds of measured driver execution.
  These counts include setup/sampler failures; they are not 880 successful calls.
- Checker design, source reading, shell actions, failed Git identity commands,
  inspection interpreters, report writing and read-only review are additional
  actual work, not included in the 17.031 seconds. Tool outputs and retained driver
  logs identify the native work. Wall time for all reasoning and provider token/
  monetary charges is not independently measured here and is not assumed zero.
- Common packet/environment preparation, evaluator confirmation, future owner
  adoption and maintenance remain costs outside these measurements. No speedup,
  cost ratio, or matched-quality superiority is claimed.
- Final native run completed at 2026-10-23T08:10:09.795839+00:00. After supported
  decisions were available, work was limited to evidence review, reporting and
  freeze metadata. No reserved examples, labels or scripts were accessed. No
  network, new agents, MCP resources, credentials, messages or session history
  were used. Adoption is conditional on subsequent evaluator confirmation.

## Reproduction

From this workspace, run the `reproduction_command` in `report.json`. It produces
`replay-evidence/report.json`, observations, assessments, process logs and source
identities. The final supplied-source checks and decisions reproduce; timestamps,
timings and output-directory path prefixes naturally differ. Optional read-only
review of regenerated evidence:

```sh
/Users/danielwahnich/workspace/nisayon-untouched-reuse-2026-10-23/artifacts/untouched-reuse-2026-10-23/evaluator-private/native-env/bin/python -B review.py --evidence replay-evidence
```

`freeze.json` records SHA-256 identities of the final solver script, report and
retained evidence. Existing author and Apache-2.0 license notices are preserved
in the supplied native trees. This qualification is not a merge decision, owner
acceptance, robot/deployment acceptance, or a physical-safety claim.
