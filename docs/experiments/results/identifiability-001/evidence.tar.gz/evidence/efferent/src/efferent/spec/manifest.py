"""Policy manifest: the self-describing contract a trained policy carries with it.

The manifest answers every question a runtime needs to drive the network:
what the observation vector is made of (semantic terms, in order), what the
action output means, which joints the policy knows about (BY NAME, in policy
order), and what control assumptions (rate, gains, scaling) it was trained
under. It deliberately contains no hardware facts — those live in the
RobotDescriptor and the two are joined by joint name at startup.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

SPEC_VERSION = 1

# Semantic observation terms the runtime knows how to produce. Custom terms
# use the "custom." prefix and are resolved via a user-registered hook.
KNOWN_TERMS = {
    "base_lin_vel",
    "base_ang_vel",
    "projected_gravity",
    "base_quat",
    "joint_pos",
    "joint_pos_rel",
    "joint_vel",
    "joint_torque",
    "last_action",
    "command",
    "time",
    "phase",
}

ActionType = Literal[
    "joint_position_delta",  # target = default_pose + scale * action
    "joint_position",  # target = scale * action
    "joint_velocity",
    "joint_torque",
]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class JointSpec(StrictModel):
    name: str
    default: float = 0.0


class ObsTerm(StrictModel):
    term: str
    scale: float | list[float] = 1.0
    history: int = 1  # 1 = current value only; N>1 stacks last N
    names: list[str] | None = None  # for `command`: names the command dims
    params: dict = Field(default_factory=dict)  # e.g. {"freq": 1.5} for phase
    dim: int | None = None  # declared size; required info for custom
    # terms to be statically checkable (doctor)

    @field_validator("term")
    @classmethod
    def _known_term(cls, v: str) -> str:
        if v not in KNOWN_TERMS and not v.startswith("custom."):
            raise ValueError(
                f"unknown observation term '{v}' "
                f"(known: {sorted(KNOWN_TERMS)}; or use a 'custom.' prefix)"
            )
        return v

    @field_validator("history")
    @classmethod
    def _history_positive(cls, v: int) -> int:
        if v < 1:
            raise ValueError("history must be >= 1")
        return v


class GainSpec(StrictModel):
    """kp/kd the policy was trained with. Scalar, or per-joint list in policy
    joint order, or a name->value mapping (longest-prefix match on joint name
    is NOT attempted — mapping keys must be exact joint names)."""

    kp: float | list[float] | dict[str, float]
    kd: float | list[float] | dict[str, float]


class ControlSpec(StrictModel):
    rate_hz: float = 50.0
    action_type: ActionType = "joint_position_delta"
    action_scale: float | list[float] = 1.0
    clip_actions: tuple[float, float] | None = None
    gains: GainSpec | None = None
    # Max change of the *raw* action per step, applied by the safety layer.
    # None disables rate limiting.
    max_action_rate: float | None = None


class PolicyIO(StrictModel):
    file: str = "policy.onnx"
    input: str = "obs"  # name of the flat observation input
    output: str = "actions"
    # Recurrent state carried across steps. A single input/output pair, or
    # parallel lists for multi-tensor state (e.g. an LSTM's h and c):
    #   state_input: [h_in, c_in], state_output: [h_out, c_out],
    #   state_init: [[1, 64], [1, 64]]
    state_input: str | list[str] | None = None
    state_output: str | list[str] | None = None
    state_init: list[int] | list[list[int]] | None = None  # zeros-init

    def states(self) -> list[tuple[str, str, list[int]]]:
        """Normalized [(input_name, output_name, init_shape)] list."""
        if self.state_input is None:
            return []
        ins = [self.state_input] if isinstance(self.state_input, str) else list(self.state_input)
        outs = (
            [self.state_output]
            if isinstance(self.state_output, str)
            else list(self.state_output or [])
        )
        init = self.state_init or []
        inits = (
            [list(init)]  # type: ignore[list-item]
            if init and isinstance(init[0], int)
            else [list(s) for s in init]  # type: ignore[union-attr]
        )
        if not (len(ins) == len(outs) == len(inits)):
            raise ValueError(
                f"state_input/state_output/state_init must have matching "
                f"lengths, got {len(ins)}/{len(outs)}/{len(inits)}"
            )
        return list(zip(ins, outs, inits, strict=True))


class StartEnvelope(StrictModel):
    """The state a policy expects to receive control in. Encodes the field
    lesson that policies have a temporal contract too: a mimic policy must
    start ON its reference motion, not at its action-offset default pose.
    The runtime refuses a handoff outside the envelope — a refused
    transition instead of a fallen robot."""

    # Pose (policy joint order) the policy expects at t=0. None -> the
    # manifest default pose.
    expected_pose: list[float] | None = None
    joint_pos_tol: float = 0.2  # rad, per joint
    max_joint_vel: float = 1.5  # rad/s, per joint
    max_tilt: float | None = None  # rad from upright; checked when quat available


class NormalizationSpec(StrictModel):
    file: str | None = None  # .npz with 'mean' and 'std' arrays
    clip_obs: float | None = None


class Provenance(StrictModel):
    model_config = ConfigDict(extra="allow")
    trained_in: str | None = None
    repo: str | None = None
    commit: str | None = None


class PolicyManifest(StrictModel):
    efferent: int = SPEC_VERSION
    name: str = "policy"
    policy: PolicyIO = Field(default_factory=PolicyIO)
    control: ControlSpec = Field(default_factory=ControlSpec)
    joints: list[JointSpec]
    observation: list[ObsTerm]
    normalization: NormalizationSpec = Field(default_factory=NormalizationSpec)
    envelope: StartEnvelope | None = None
    provenance: Provenance = Field(default_factory=Provenance)

    @model_validator(mode="after")
    def _validate(self) -> PolicyManifest:
        if self.efferent != SPEC_VERSION:
            raise ValueError(
                f"manifest spec version {self.efferent} not supported "
                f"(runtime speaks version {SPEC_VERSION})"
            )
        names = [j.name for j in self.joints]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ValueError(f"duplicate joint names in manifest: {sorted(dupes)}")
        if not self.joints:
            raise ValueError("manifest must declare at least one joint")
        if not self.observation:
            raise ValueError("manifest must declare at least one observation term")
        for attr in ("action_scale",):
            v = getattr(self.control, attr)
            if isinstance(v, list) and len(v) != len(self.joints):
                raise ValueError(
                    f"control.{attr} has {len(v)} entries but manifest declares "
                    f"{len(self.joints)} joints"
                )
        if (
            self.envelope is not None
            and self.envelope.expected_pose is not None
            and len(self.envelope.expected_pose) != len(self.joints)
        ):
            raise ValueError(
                f"envelope.expected_pose has {len(self.envelope.expected_pose)} "
                f"entries but manifest declares {len(self.joints)} joints"
            )
        if self.control.gains is not None:
            for gname in ("kp", "kd"):
                g = getattr(self.control.gains, gname)
                if isinstance(g, list) and len(g) != len(self.joints):
                    raise ValueError(
                        f"control.gains.{gname} has {len(g)} entries but manifest "
                        f"declares {len(self.joints)} joints"
                    )
                if isinstance(g, dict):
                    missing = set(g) - set(names)
                    if missing:
                        raise ValueError(
                            f"control.gains.{gname} references unknown joints: {sorted(missing)}"
                        )
        return self

    # -- convenience ---------------------------------------------------------

    @property
    def joint_names(self) -> list[str]:
        return [j.name for j in self.joints]

    @property
    def default_pose(self) -> list[float]:
        return [j.default for j in self.joints]

    def num_joints(self) -> int:
        return len(self.joints)
