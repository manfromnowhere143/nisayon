"""Backend ABI — the entire hardware surface of efferent.

A backend adapts one robot SDK (or one simulator) to five methods. Everything
else — observation building, inference, safety, timing — lives in the core
runtime and is shared by all robots.
"""

from __future__ import annotations

from importlib.metadata import entry_points
from typing import Protocol, runtime_checkable

from ..spec.descriptor import RobotDescriptor
from ..types import JointCommand, RobotState


@runtime_checkable
class Backend(Protocol):
    #: True for simulators that advance their own clock inside write();
    #: the scheduler then skips wall-clock pacing and runs as fast as possible.
    advances_time: bool = False

    def connect(self, descriptor: RobotDescriptor) -> None: ...

    def read(self) -> RobotState: ...

    def write(self, cmd: JointCommand) -> None: ...

    def estop(self) -> None:
        """Best-effort transition to a safe state (typically pure damping)."""
        ...

    def close(self) -> None: ...


_BUILTIN = {
    "mock": "efferent.backends.mock:MockBackend",
    "mujoco": "efferent.backends.mujoco_backend:MujocoBackend",
    "unitree-dds": "efferent.backends.unitree_dds:UnitreeDdsBackend",
}


def load_backend(backend_id: str, params: dict) -> Backend:
    """Resolve a backend by id: installed entry points first, then built-ins."""
    target = None
    try:
        eps = entry_points(group="efferent.backends")
        for ep in eps:
            if ep.name == backend_id:
                target = ep.load()
                break
    except Exception:  # pragma: no cover - metadata lookup is best-effort
        pass
    if target is None:
        spec = _BUILTIN.get(backend_id)
        if spec is None:
            raise KeyError(
                f"unknown backend '{backend_id}'. Installed/built-in backends: "
                f"{sorted(set(_BUILTIN) | {ep.name for ep in entry_points(group='efferent.backends')})}"
            )
        mod_name, _, cls_name = spec.partition(":")
        import importlib

        target = getattr(importlib.import_module(mod_name), cls_name)
    return target(**params)
