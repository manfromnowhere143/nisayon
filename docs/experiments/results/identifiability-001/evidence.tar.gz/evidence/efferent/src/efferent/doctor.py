"""efferent.doctor — preflight checks that catch deployment bugs before the
robot moves.

The bug class this targets is the one that fills deployment repos' issue
trackers: a subtly mis-wired observation pipeline. Wrong joint order, a term
in the wrong frame or units, command dims connected to nothing — none of
which crash, all of which make the robot fall, and today all debugged by
staring at numbers after the fact.

Three lines:

    import efferent
    report = efferent.doctor("policy.app", robot="g1.robot.yaml")
    print(report)          # or: assert report.passed

How it works: beyond static contract checks, the doctor probes the actual
network with finite-difference sensitivity analysis. A trained policy has
structure — perturbing joint i's position must move action i more than any
other action; command dims must influence *something*; extreme inputs must
not produce NaNs. Violated structure localizes the wiring bug, and for
joint-order mismatches the doctor reconstructs and prints the permutation
it thinks you meant.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .package import load_descriptor, load_policy
from .runtime.policy import PolicySession
from .spec.binding import Binding, BindingError
from .spec.manifest import PolicyManifest

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"


@dataclass
class Check:
    name: str
    status: str
    detail: str = ""


@dataclass
class DoctorReport:
    checks: list[Check] = field(default_factory=list)

    def add(self, name: str, status: str, detail: str = "") -> None:
        self.checks.append(Check(name, status, detail))

    @property
    def passed(self) -> bool:
        return all(c.status != FAIL for c in self.checks)

    @property
    def failures(self) -> list[Check]:
        return [c for c in self.checks if c.status == FAIL]

    def __str__(self) -> str:
        icon = {PASS: "[ok]  ", WARN: "[warn]", FAIL: "[FAIL]"}
        lines = ["efferent doctor report", "-" * 60]
        for c in self.checks:
            lines.append(f"{icon[c.status]} {c.name}")
            if c.detail:
                for d in c.detail.splitlines():
                    lines.append(f"        {d}")
        lines.append("-" * 60)
        n_fail = len(self.failures)
        n_warn = sum(1 for c in self.checks if c.status == WARN)
        lines.append(
            f"verdict: {'PASS' if self.passed else 'FAIL'} "
            f"({len(self.checks)} checks, {n_warn} warnings, {n_fail} failures)"
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------


def doctor(
    policy: str | Path,
    robot: str | Path | None = None,
    manifest: str | Path | None = None,
    reference: str | Path | None = None,
    eps: float = 0.05,
) -> DoctorReport:
    """Run every applicable preflight check. Never raises for policy defects —
    defects become FAIL entries; only unusable inputs (missing files) raise.

    Zero-config mode: given a bare .onnx with no manifest anywhere, the doctor
    still runs — it synthesizes a placeholder manifest from the graph I/O and
    locates the joint blocks empirically from the network's own sensitivity
    structure instead of a declared recipe.
    """
    report = DoctorReport()

    try:
        mf, onnx_path, workdir = load_policy(policy, manifest)
        zero_config = False
    except FileNotFoundError:
        mf, onnx_path, workdir = (
            _synthesize_manifest(Path(policy)),
            Path(policy),
            Path(policy).parent,
        )
        zero_config = True
        report.add(
            "manifest",
            WARN,
            "no manifest found - running in zero-config mode: joint "
            "count taken from the action output, obs layout inferred "
            "from the network's sensitivity structure",
        )

    if zero_config:
        try:
            session = PolicySession(mf, onnx_path, norm_dir=workdir)
            report.add("model loads", PASS)
        except Exception as e:
            report.add("model loads", FAIL, str(e))
            return report
        _check_recurrent_export(report, onnx_path, mf)
        obs_dim = session.expected_obs_dim
        if obs_dim is None:
            report.add(
                "observation dimension resolvable",
                FAIL,
                "dynamically-shaped input; zero-config mode needs a static obs size",
            )
            return report
        sens = _check_numerics(report, mf, session, obs_dim, eps)
        if sens is not None:
            _zero_config_layout(report, sens, mf.num_joints())
        if reference is not None:
            _check_replay(report, session, reference)
        return report
    try:
        session = PolicySession(mf, onnx_path, norm_dir=workdir)
        report.add("model loads and matches manifest I/O names", PASS)
    except Exception as e:
        report.add("model loads and matches manifest I/O names", FAIL, str(e))
        return report

    _check_recurrent_export(report, onnx_path, mf)
    _check_contract(report, mf, session)
    obs_dim = session.expected_obs_dim or _recipe_dim(mf)
    if obs_dim is None:
        report.add(
            "observation dimension resolvable",
            FAIL,
            "neither the ONNX graph nor the manifest pins the obs size",
        )
        return report

    sens = _check_numerics(report, mf, session, obs_dim, eps)
    if sens is not None:
        _check_joint_order(report, mf, session, sens, obs_dim, eps)
        _check_dead_terms(report, mf, sens)
    if robot is not None:
        _check_binding(report, mf, load_descriptor(robot))
    _check_gain_sanity(report, mf)
    if reference is not None:
        _check_replay(report, session, reference)
    return report


def _check_recurrent_export(report: DoctorReport, onnx_path: Path, mf: PolicyManifest) -> None:
    """A recurrent network (LSTM/GRU/RNN nodes in the graph) exported WITHOUT
    exposed state inputs re-initializes its memory on every call — it runs,
    produces sane-looking actions, and silently behaves nothing like it did
    in training. Common with torch.jit -> ONNX exports of rsl_rl policies."""
    import onnx as onnx_lib

    try:
        model = onnx_lib.load(str(onnx_path), load_external_data=False)
    except Exception:
        return
    recurrent_ops = {"LSTM", "GRU", "RNN", "Scan"}
    found = sorted({n.op_type for n in model.graph.node if n.op_type in recurrent_ops})
    if not found:
        return
    if mf.policy.states():
        report.add(
            "recurrent state exposure",
            PASS,
            f"graph contains {found} and the manifest carries its state",
        )
        return
    report.add(
        "recurrent state exposure",
        WARN,
        f"graph contains recurrent ops {found} but NO state inputs are "
        f"declared/exposed - exported this way the network re-initializes "
        f"its memory EVERY call and will not behave as it did in training. "
        f"Re-export with hidden state as explicit inputs/outputs (h/c for "
        f"LSTM) and declare them via policy.state_input/state_output "
        f"(lists are supported)",
    )


# -- zero-config support -----------------------------------------------------


def _synthesize_manifest(onnx_path: Path) -> PolicyManifest:
    """Placeholder manifest for a bare ONNX: joints from the action dim,
    I/O names from the graph, obs declared as one opaque custom block."""
    import onnxruntime as ort

    from .spec.manifest import JointSpec, ObsTerm, PolicyIO

    sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    inp, out = sess.get_inputs()[0], sess.get_outputs()[0]
    n_act = next(d for d in reversed(out.shape) if isinstance(d, int))
    obs_dim = next((d for d in reversed(inp.shape) if isinstance(d, int)), None)
    return PolicyManifest(
        name=onnx_path.stem,
        policy=PolicyIO(file=onnx_path.name, input=inp.name, output=out.name),
        joints=[JointSpec(name=f"joint_{i:02d}") for i in range(n_act)],
        observation=[ObsTerm(term="custom.unknown_layout", dim=obs_dim)],
    )


# Known sizes of non-joint front/back matter, used only to NAME what the
# structural scan finds (the scan itself is convention-free).
_BLOCK_NAMES = {
    3: "one 3-dim block (ang_vel | gravity | lin_vel | command)",
    6: "two 3-dim blocks (e.g. ang_vel + gravity)",
    9: "ang_vel + gravity + command  (legged_gym convention)",
    11: "ang_vel + gravity + command + phase(2)  (unitree_rl_gym convention)",
    12: "lin_vel + ang_vel + gravity + command",
    16: "lin_vel + ang_vel + gravity + command + phase(4)  (mujoco_playground humanoids)",
}


def _diag_score(S: np.ndarray, off: int, n: int) -> tuple[float, float]:
    """(fraction of active dims whose argmax is diagonal, mean diagonal
    magnitude) for the n-wide block starting at obs offset `off`."""
    sub = np.abs(S[off : off + n, :n])
    active = sub.max(axis=1) > (np.abs(S).max() * 1e-3)
    if active.sum() < max(2, n // 2):
        return 0.0, 0.0
    diag_ok = (sub.argmax(axis=1) == np.arange(n))[active]
    return float(diag_ok.mean()), float(np.trace(sub) / n)


def _block_mapping(S: np.ndarray, off: int, n: int) -> list[int] | None:
    """If the n-wide block at `off` is joint-indexed — every row strongly
    peaked on one action, and the peaks form a bijection — return that
    obs->action mapping. Peaked means the max clearly dominates the row
    (>= 3x the row median), which dense/coupled Jacobians do not produce."""
    sub = np.abs(S[off : off + n, :n])
    if (sub.max(axis=1) <= np.abs(S).max() * 1e-3).any():
        return None
    med = np.median(sub, axis=1)
    if not (sub.max(axis=1) >= 3.0 * np.maximum(med, 1e-12)).all():
        return None
    mapping = sub.argmax(axis=1)
    if len(set(mapping.tolist())) != n:
        return None
    return mapping.tolist()


def _zero_config_layout(report: DoctorReport, S: np.ndarray, n: int) -> None:
    """Locate the joint-indexed blocks by scanning for diagonal sensitivity
    structure — works for any front/back-matter arrangement, no convention
    assumed. Then name the residual segments if their sizes match known
    conventions."""
    D = S.shape[0]
    if 3 * n > D:
        report.add(
            "obs layout (zero-config)",
            WARN,
            f"obs ({D}) smaller than 3x action dim ({3 * n}); "
            f"non-standard architecture, layout scan skipped",
        )
        return

    # Every offset competes with its best interpretation, and one unified
    # greedy (strongest magnitude first, non-overlapping) decides the layout:
    # - healthy: >= 60% of active rows respond on the diagonal (tolerant —
    #   real policies have coupling noise); evidence = diagonal energy.
    # - permuted: every row sharply peaked, peaks form a mostly-non-identity
    #   bijection (strict — decisive evidence only); evidence = peak energy.
    # A shifted window of a true block always carries less energy than the
    # true block itself, so aliased neighbors lose the greedy competition —
    # in both directions (healthy masking permuted and vice versa).
    cands: list[tuple[float, int, str, float, list[int] | None]] = []
    for off in range(D - n + 1):
        frac, dmag = _diag_score(S, off, n)
        if frac >= 0.6:
            cands.append((dmag, off, "healthy", frac, None))
        mapping = _block_mapping(S, off, n)
        if mapping is not None and mapping != list(range(n)):
            # Guard against noise strays on healthy blocks: every displaced
            # row's peak must clearly dominate that row's own diagonal entry.
            # A truly swapped pair has a near-zero diagonal; a noise-caused
            # stray argmax sits barely above a strong diagonal and fails this.
            sub = np.abs(S[off : off + n, :n])
            displaced = [i for i, m in enumerate(mapping) if m != i]
            if all(sub[i, mapping[i]] >= 3.0 * (sub[i, i] + 1e-12) for i in displaced):
                pmag = float(sub.max(axis=1).mean())
                cands.append((pmag, off, "permuted", 0.0, mapping))

    picks: list[tuple[int, float, float]] = []
    permuted: list[tuple[int, list[int]]] = []
    for mag, off, kind, frac, mapping in sorted(cands, key=lambda x: -x[0]):
        taken = [o for o, _, _ in picks] + [o for o, _ in permuted]
        if any(abs(off - o) < n for o in taken):
            continue
        if kind == "healthy":
            picks.append((off, frac, mag))
        else:
            permuted.append((off, mapping))  # type: ignore[arg-type]
    picks.sort()
    permuted.sort()

    if permuted:
        lines = []
        if picks:
            lines.append(
                "INTERNALLY INCONSISTENT joint ordering: some joint-indexed "
                "obs blocks match the action order, but these do not:"
            )
        else:
            lines.append(
                "joint-indexed obs block(s) are ordered DIFFERENTLY than the "
                "action output - obs and action joint orders disagree:"
            )
        for off, mapping in permuted:
            lines.append(f"  dims {off:>3}..{off + n - 1:<3} -> obs->action mapping {mapping}")
        lines.append(
            "this is the classic permuted joint-order bug; reorder the obs "
            "wiring (or the manifest joints) per the mapping above and re-run"
        )
        report.add("obs layout (zero-config structural scan)", FAIL, "\n".join(lines))
        return

    if not picks:
        # No per-joint diagonal structure. Genuinely the case for dynamic
        # gait policies (quadruped trots couple all legs), not only for
        # weird architectures — so report the influence profile instead of
        # guessing.
        influence = np.abs(S).sum(axis=1)
        hot = influence > influence.mean() + 2 * influence.std()
        groups, start = [], None
        for i, h in enumerate(list(hot) + [False]):
            if h and start is None:
                start = i
            elif not h and start is not None:
                groups.append((start, i - 1))
                start = None
        lines = [
            "no per-joint diagonal structure found - typical of dynamic "
            "gait policies (fully-coupled Jacobian), RNN/history stacks, "
            "or torque control; layout not inferable from probing alone"
        ]
        if groups:
            lines.append(
                "high-influence dim groups (candidate IMU/gravity/"
                "command blocks): " + ", ".join(f"{a}..{b}" for a, b in groups)
            )
        lines.append("provide a manifest to unlock the full check suite")
        report.add("obs layout (zero-config)", WARN, "\n".join(lines))
        return

    # A consecutive run spaced exactly n apart is the classic
    # jpos / jvel / last_action triplet.
    runs: list[list[tuple[int, float, float]]] = [[picks[0]]]
    for p in picks[1:]:
        if p[0] - runs[-1][-1][0] == n:
            runs[-1].append(p)
        else:
            runs.append([p])
    best_run = max(runs, key=len)
    start = best_run[0][0]
    labels = ["joint_pos", "joint_vel", "last_action"][: len(best_run)]
    lines = [
        f"joint-indexed blocks located at offsets "
        f"{[p[0] for p in best_run]} (diagonal {best_run[0][1]:.0%} on the "
        f"strongest block)"
    ]
    for (off, frac, _), lab in zip(best_run, labels, strict=True):
        lines.append(f"  dims {off:>3}..{off + n - 1:<3} -> {lab} (diagonal {frac:.0%})")
    lead, trail = start, D - (best_run[-1][0] + n)
    if lead:
        lines.append(
            f"  dims   0..{lead - 1:<3} -> "
            + _BLOCK_NAMES.get(lead, f"{lead} unidentified dims (IMU/command/phase)")
        )
    if trail:
        t0 = best_run[-1][0] + n
        lines.append(
            f"  dims {t0:>3}..{D - 1:<3} -> "
            + _BLOCK_NAMES.get(trail, f"{trail} unidentified dims (command/phase/extra)")
        )
    lines.append(
        "write a manifest with this layout to unlock full checks (binding, gains, per-term scales)"
    )
    status = PASS if len(best_run) >= 2 and best_run[0][1] >= 0.8 else WARN
    report.add("obs layout (zero-config structural scan)", status, "\n".join(lines))


# -- individual checks -------------------------------------------------------


def _term_dim(mf: PolicyManifest, t) -> int | None:
    known = {
        "base_lin_vel": 3,
        "base_ang_vel": 3,
        "projected_gravity": 3,
        "base_quat": 4,
        "time": 1,
        "phase": 2,
    }
    if t.dim is not None:
        return t.dim
    if t.term in ("joint_pos", "joint_pos_rel", "joint_vel", "joint_torque", "last_action"):
        return mf.num_joints()
    if t.term == "command":
        return len(t.names) if t.names else 3
    return known.get(t.term)  # None for undeclared custom terms


def _recipe_dim(mf: PolicyManifest) -> int | None:
    total = 0
    for t in mf.observation:
        d = _term_dim(mf, t)
        if d is None:
            return None  # custom term without declared dim
        total += d * t.history
    return total


def _term_layout(mf: PolicyManifest, obs_dim: int) -> list[tuple[str, int, int]] | None:
    """[(term, offset, dim)] if every term's size is statically known (custom
    terms can be inferred when exactly one is unknown)."""
    dims: list[int | None] = []
    for t in mf.observation:
        d = _term_dim(mf, t)
        dims.append(None if d is None else d * t.history)
    unknown = [i for i, d in enumerate(dims) if d is None]
    if len(unknown) == 1:
        dims[unknown[0]] = obs_dim - sum(d for d in dims if d is not None)  # type: ignore[misc]
    elif unknown:
        return None
    if sum(d for d in dims) != obs_dim:  # type: ignore[misc]
        return None
    layout, off = [], 0
    for t, d in zip(mf.observation, dims, strict=True):
        layout.append((t.term, off, d))  # type: ignore[arg-type]
        off += d  # type: ignore[operator]
    return layout


def _check_contract(report: DoctorReport, mf: PolicyManifest, session: PolicySession) -> None:
    expect = _recipe_dim(mf)
    got = session.expected_obs_dim
    if expect is None:
        report.add(
            "obs recipe size vs network input",
            WARN,
            f"manifest uses custom terms; static size check skipped (network expects {got})",
        )
    elif got is None:
        report.add(
            "obs recipe size vs network input",
            WARN,
            f"network input is dynamically shaped; recipe produces {expect}",
        )
    elif expect == got:
        report.add("obs recipe size vs network input", PASS, f"{expect} dims")
    else:
        report.add(
            "obs recipe size vs network input",
            FAIL,
            f"manifest recipe produces {expect} dims, network expects {got}",
        )


def _probe(session: PolicySession, x: np.ndarray) -> np.ndarray:
    return session.step(x.astype(np.float32))


def _check_numerics(
    report: DoctorReport, mf: PolicyManifest, session: PolicySession, obs_dim: int, eps: float
) -> np.ndarray | None:
    """Extreme/noise inputs must stay finite; also computes and returns the
    sensitivity matrix S[i, j] = d action_j / d obs_i for downstream checks."""
    rng = np.random.default_rng(0)
    probes = {
        "zeros": np.zeros(obs_dim),
        "ones": np.ones(obs_dim),
        "large +": np.full(obs_dim, 100.0),
        "large -": np.full(obs_dim, -100.0),
        "noise": rng.normal(0, 1, obs_dim),
    }
    bad = []
    for name, x in probes.items():
        try:
            a = _probe(session, x)
            if not np.isfinite(a).all():
                bad.append(f"{name}: non-finite actions")
        except Exception as e:
            bad.append(f"{name}: {type(e).__name__}: {e}")
    if bad:
        report.add("numeric robustness (extreme inputs stay finite)", FAIL, "\n".join(bad))
        return None
    report.add("numeric robustness (extreme inputs stay finite)", PASS)

    # Average |Jacobian| over several nominal points: a single point (zeros)
    # can sit far off-distribution for e.g. mimic policies and give a noisy
    # fingerprint.
    n_act = _probe(session, np.zeros(obs_dim)).shape[0]
    S = np.zeros((obs_dim, n_act), dtype=np.float64)
    points = [np.zeros(obs_dim)] + [rng.normal(0, 0.3, obs_dim) for _ in range(5)]
    for x0 in points:
        for i in range(obs_dim):
            xp, xm = x0.copy(), x0.copy()
            xp[i] += eps
            xm[i] -= eps
            S[i] += np.abs(_probe(session, xp) - _probe(session, xm)) / (2 * eps)
    S /= len(points)
    if not np.isfinite(S).all():
        report.add("sensitivity probe", FAIL, "non-finite gradients around nominal obs")
        return None
    if np.abs(S).max() < 1e-8:
        report.add(
            "sensitivity probe",
            FAIL,
            "network output does not depend on its input at the nominal point - wrong model file?",
        )
        return None
    return S


def _check_joint_order(
    report: DoctorReport,
    mf: PolicyManifest,
    session: PolicySession,
    S: np.ndarray,
    obs_dim: int,
    eps: float,
) -> None:
    """A position(-delta) policy must respond to joint i's position error
    chiefly with action i. A shuffled argmax pattern that forms a permutation
    is the classic joint-order bug — reconstruct and report it."""
    if mf.control.action_type not in ("joint_position_delta", "joint_position"):
        return
    layout = _term_layout(mf, obs_dim)
    if layout is None:
        report.add(
            "joint-order fingerprint",
            WARN,
            "could not statically locate the joint_pos block (multiple "
            "custom terms); check skipped",
        )
        return
    n = mf.num_joints()
    blocks = [
        (t, off, d) for (t, off, d) in layout if t in ("joint_pos_rel", "joint_pos") and d == n
    ]
    if not blocks:
        return
    term, off, _ = blocks[0]
    sub = np.abs(S[off : off + n, :n])  # joint_pos dims x joint actions
    col_max = sub.max(axis=1)
    active = col_max > (np.abs(S).max() * 1e-3)
    if active.sum() < n * 0.5:
        report.add(
            "joint-order fingerprint",
            WARN,
            f"only {int(active.sum())}/{n} joint_pos dims influence the "
            f"action at the nominal point; fingerprint inconclusive",
        )
        return
    argmax = sub.argmax(axis=1)
    diag_ok = argmax == np.arange(n)
    frac = diag_ok[active].mean()
    if frac >= 0.8:
        report.add(
            "joint-order fingerprint",
            PASS,
            f"{term}: {int(diag_ok[active].sum())}/{int(active.sum())} "
            f"active joints respond on the diagonal",
        )
        return
    # Is the argmax pattern (restricted to active dims) a permutation?
    perm_like = len(set(argmax[active].tolist())) == int(active.sum())
    if perm_like:
        report.add(
            "joint-order fingerprint",
            FAIL,
            f"{term} block looks PERMUTED relative to the action order: only "
            f"{frac:.0%} of joints respond on the diagonal.\n"
            f"observed obs->action mapping: {argmax.tolist()}\n"
            f"if training used this order, reorder manifest `joints` with "
            f"that mapping (or fix the obs wiring) and re-run doctor",
        )
    else:
        report.add(
            "joint-order fingerprint",
            WARN,
            f"diagonal response {frac:.0%}, off-diagonal responses are not a "
            f"permutation - typical of whole-body coordination (e.g. mimic "
            f"policies, hip->ankle / shoulder->wrist coupling), not a wiring bug",
        )


def _check_dead_terms(report: DoctorReport, mf: PolicyManifest, S: np.ndarray) -> None:
    """Every obs term the manifest declares should influence the action
    somewhere. A dead command block is the classic 'robot ignores the
    joystick' bug; a dead ang-vel block means the IMU wiring does nothing."""
    layout = _term_layout(mf, S.shape[0])
    if layout is None:
        return
    scale = np.abs(S).max()
    dead = []
    for term, off, d in layout:
        if d == 0:
            continue
        block = np.abs(S[off : off + d, :])
        if block.max() < scale * 1e-4:
            dead.append(f"{term} (dims {off}..{off + d - 1})")
    if dead:
        report.add(
            "no dead observation terms",
            WARN,
            "these terms have ~zero influence on the action at the "
            "nominal point:\n"
            + "\n".join(dead)
            + "\n(wrong wiring, or the policy genuinely ignores them)",
        )
    else:
        report.add("no dead observation terms", PASS)


def _check_binding(report: DoctorReport, mf: PolicyManifest, descriptor) -> None:
    try:
        Binding(mf, descriptor)
        report.add(
            f"binds to robot '{descriptor.robot}' by name",
            PASS,
            f"{mf.num_joints()} policy joints -> {descriptor.num_joints()} hardware joints",
        )
    except BindingError as e:
        report.add(f"binds to robot '{descriptor.robot}' by name", FAIL, str(e))


def _check_gain_sanity(report: DoctorReport, mf: PolicyManifest) -> None:
    ctrl = mf.control
    n = mf.num_joints()
    scale = np.asarray(
        ctrl.action_scale if isinstance(ctrl.action_scale, list) else [ctrl.action_scale] * n,
        dtype=np.float64,
    )
    clip = ctrl.clip_actions
    a_max = min(abs(clip[0]), abs(clip[1])) if clip else 3.0  # ~3 sigma raw action
    step = scale * a_max
    issues = []
    if (step > 3.0).any():
        worst = mf.joint_names[int(np.argmax(step))]
        issues.append(
            f"action_scale x plausible action reaches {step.max():.1f} rad "
            f"(joint '{worst}') - one policy step can command a huge jump; "
            f"consider clip_actions or max_action_rate"
        )
    if ctrl.rate_hz > 200 or ctrl.rate_hz < 10:
        issues.append(f"unusual policy rate {ctrl.rate_hz} Hz")
    if issues:
        report.add("control parameter sanity", WARN, "\n".join(issues))
    else:
        report.add("control parameter sanity", PASS)


def _check_replay(report: DoctorReport, session: PolicySession, reference: str | Path) -> None:
    """Replay recorded (obs, actions) pairs — e.g. exported from the training
    framework's play script — through the deployed session. Divergence means
    the deployment pipeline (normalization, clipping, model file) is not the
    one that produced the recording."""
    data = np.load(reference)
    if "obs" not in data or "actions" not in data:
        report.add(
            "reference replay", FAIL, "reference file must contain 'obs' [T,D] and 'actions' [T,A]"
        )
        return
    obs, ref = data["obs"], data["actions"]
    session.reset()
    errs = []
    for t in range(len(obs)):
        a = session.step(obs[t])
        errs.append(np.abs(a - ref[t]).max())
    worst = float(np.max(errs))
    if worst < 1e-3:
        report.add(
            "reference replay", PASS, f"{len(obs)} recorded steps reproduced (max |da| {worst:.2e})"
        )
    else:
        t_bad = int(np.argmax(errs))
        report.add(
            "reference replay",
            FAIL,
            f"deployed pipeline diverges from the recording: max |da| "
            f"{worst:.4f} at step {t_bad} — normalization stats, action "
            f"clip, or model file differ from what produced the reference",
        )
