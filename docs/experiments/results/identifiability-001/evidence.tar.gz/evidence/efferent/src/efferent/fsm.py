"""Declarative multi-policy FSM: the deployment protocol as config.

Real deployments are never "run one policy": they are damp -> stand -> policy
-> recover sequences, and today that protocol lives in hand-written C++ per
robot. Here it is YAML:

    robot: g1_29dof.robot.yaml
    initial: idle
    states:
      idle:  {type: damp, duration_s: 1.0}
      stand: {type: pose, target_from: jab, duration_s: 3.0, hold_s: 1.0}
      jab:   {type: policy, policy: g1_jab.app, hook: jab_hook.py, duration_s: 11.0}
      done:  {type: damp, duration_s: 1.0}
    transitions:
      - {from: idle,  to: stand}
      - {from: stand, to: jab}
      - {from: jab,   to: done}

State types:
- ``damp``   — pure damping (descriptor safe_kd) for duration_s.
- ``pose``   — interpolate to a target pose with the descriptor's safe gains
  (optionally scaled), then hold. The target is a literal hardware-order
  list, or ``target_from: <policy state>`` = that policy's start envelope
  pose — so "stand where the next policy expects to start" is one line.
- ``policy`` — run a policy package through the standard Runner (same obs
  builder, safety layer, and START-ENVELOPE CHECK as a standalone run; an
  out-of-envelope handoff is refused and the FSM drops to damping).

Each state runs to completion, then follows its single outgoing transition;
any estop or refused handoff terminates the sequence into damping. This is
deliberately a sequential protocol first — conditional/event transitions
(gamepad, external triggers) layer on later without changing the format.
"""

from __future__ import annotations

import contextlib
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import numpy as np
import yaml
from pydantic import BaseModel, ConfigDict, Field

from .backends.base import Backend, load_backend
from .package import load_descriptor, load_policy
from .runtime.loop import Runner, RunResult
from .runtime.policy import PolicySession
from .spec.binding import Binding
from .types import Command, JointCommand

logger = logging.getLogger("efferent.fsm")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FsmStateSpec(StrictModel):
    type: Literal["damp", "pose", "policy"]
    duration_s: float = 2.0
    # pose:
    target: list[float] | None = None  # hardware order
    target_from: str | None = None  # policy state name -> its envelope pose
    hold_s: float = 0.5
    gain_scale: float = 1.0  # scales descriptor safe gains
    # policy:
    policy: str | None = None  # .app / .onnx path (relative to fsm file)
    hook: str | None = None
    command: list[float] | None = None


class FsmTransitionSpec(StrictModel):
    from_: str = Field(alias="from")
    to: str


class FsmSpec(StrictModel):
    robot: str
    initial: str
    states: dict[str, FsmStateSpec]
    transitions: list[FsmTransitionSpec]

    @classmethod
    def load(cls, path: str | Path) -> FsmSpec:
        spec = cls.model_validate(yaml.safe_load(Path(path).read_text(encoding="utf-8")))
        names = set(spec.states)
        for t in spec.transitions:
            unknown = {t.from_, t.to} - names
            if unknown:
                raise ValueError(f"transition references unknown state(s): {sorted(unknown)}")
        if spec.initial not in names:
            raise ValueError(f"initial state '{spec.initial}' not defined")
        outgoing: dict[str, str] = {}
        for t in spec.transitions:
            if t.from_ in outgoing:
                raise ValueError(f"state '{t.from_}' has multiple outgoing transitions")
            outgoing[t.from_] = t.to
        for name, st in spec.states.items():
            if st.type == "pose" and (st.target is None) == (st.target_from is None):
                raise ValueError(f"pose state '{name}' needs exactly one of target / target_from")
            if st.type == "policy" and st.policy is None:
                raise ValueError(f"policy state '{name}' needs a policy path")
            if st.target_from is not None:
                ref = spec.states.get(st.target_from)
                if ref is None or ref.type != "policy":
                    raise ValueError(f"pose state '{name}': target_from must name a policy state")
        return spec


@dataclass
class FsmResult:
    sequence: list[str] = field(default_factory=list)
    completed: bool = False
    stop_reason: str = ""
    policy_results: dict[str, RunResult] = field(default_factory=dict)


class FsmRunner:
    def __init__(self, spec: FsmSpec, base_dir: str | Path, backend: Backend | None = None):
        self.spec = spec
        base = Path(base_dir)
        self.descriptor = load_descriptor(
            p if (p := Path(spec.robot)).is_absolute() else base / spec.robot
        )
        self.backend = backend or load_backend(
            self.descriptor.backend.id, self.descriptor.backend.params
        )
        self.nh = self.descriptor.num_joints()

        # Preload every policy state: manifest, session, binding, runner.
        self._policies: dict[str, tuple[Binding, PolicySession, Runner]] = {}
        for name, st in spec.states.items():
            if st.type != "policy":
                continue
            if st.hook:
                self._exec_hook(base / st.hook if not Path(st.hook).is_absolute() else st.hook)
            path = Path(st.policy)
            manifest, onnx_path, workdir = load_policy(path if path.is_absolute() else base / path)
            binding = Binding(manifest, self.descriptor)
            session = PolicySession(manifest, onnx_path, norm_dir=workdir)
            cmd = Command(values=np.asarray(st.command, dtype=np.float32)) if st.command else None
            runner = Runner(
                binding,
                session,
                self.backend,
                command_source=(lambda t, c=cmd: c) if cmd else None,
                owns_backend=False,
            )
            self._policies[name] = (binding, session, runner)

        # Resolve pose targets to hardware-order arrays.
        self._pose_targets: dict[str, np.ndarray] = {}
        for name, st in spec.states.items():
            if st.type != "pose":
                continue
            if st.target is not None:
                if len(st.target) != self.nh:
                    raise ValueError(
                        f"pose state '{name}': target has {len(st.target)} entries, "
                        f"descriptor has {self.nh} joints"
                    )
                self._pose_targets[name] = np.asarray(st.target, dtype=np.float32)
            else:
                binding, _, _ = self._policies[st.target_from]
                env = binding.manifest.envelope
                pose_p = np.asarray(
                    env.expected_pose
                    if env is not None and env.expected_pose is not None
                    else binding.manifest.default_pose,
                    dtype=np.float32,
                )
                # Undriven joints hold zero target; refined at runtime to
                # the current measured position.
                self._pose_targets[name] = binding.to_hardware(
                    pose_p, fill=np.zeros(self.nh, dtype=np.float32)
                )
                self._pose_fill_current = name  # marker: fill from live q

        self._dt = 0.02
        self._deadline: float | None = None

    @staticmethod
    def _exec_hook(path: str | Path) -> None:
        import importlib.util

        spec = importlib.util.spec_from_file_location(f"efferent_fsm_hook_{Path(path).stem}", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

    # ------------------------------------------------------------------

    def run(self) -> FsmResult:
        result = FsmResult()
        outgoing = {t.from_: t.to for t in self.spec.transitions}
        try:
            self.backend.connect(self.descriptor)
            current: str | None = self.spec.initial
            while current is not None:
                st = self.spec.states[current]
                result.sequence.append(current)
                logger.info("FSM state: %s (%s)", current, st.type)
                if st.type == "damp":
                    self._run_damp(st)
                elif st.type == "pose":
                    self._run_pose(current, st)
                else:
                    run_res = self._run_policy_state(current, st)
                    result.policy_results[current] = run_res
                    if run_res.estopped:
                        result.stop_reason = (
                            f"policy state '{current}' estopped: {run_res.estop_reason}"
                        )
                        self._damp_out()
                        return result
                current = outgoing.get(current)
            result.completed = True
        except Exception as e:
            result.stop_reason = f"{type(e).__name__}: {e}"
            logger.exception("FSM crashed; damping out")
            self._damp_out()
            raise
        finally:
            with contextlib.suppress(Exception):
                self.backend.close()
        return result

    # ------------------------------------------------------------------

    def _run_damp(self, st: FsmStateSpec) -> None:
        kd = np.array([j.safe_kd for j in self.descriptor.joints], dtype=np.float32)
        cmd = JointCommand.damped(self.nh, kd=kd)
        for _ in range(max(1, int(st.duration_s / self._dt))):
            self.backend.write(cmd)
            self._pace()

    def _run_pose(self, name: str, st: FsmStateSpec) -> None:
        state = self.backend.read()
        q0 = np.asarray(state.q, dtype=np.float32).copy()
        target = self._pose_targets[name].copy()
        if st.target_from is not None:
            # joints the policy does not drive: hold current position
            binding, _, _ = self._policies[st.target_from]
            driven = np.zeros(self.nh, dtype=bool)
            driven[binding.p2h] = True
            target[~driven] = q0[~driven]
        kp = np.array([j.safe_kp for j in self.descriptor.joints], dtype=np.float32) * st.gain_scale
        kd = np.array([j.safe_kd for j in self.descriptor.joints], dtype=np.float32) * max(
            1.0, st.gain_scale * 0.5
        )
        steps = max(1, int(st.duration_s / self._dt))
        hold = max(0, int(st.hold_s / self._dt))
        for i in range(steps + hold):
            alpha = min(1.0, (i + 1) / steps)
            cmd = JointCommand(
                q_des=(1 - alpha) * q0 + alpha * target,
                dq_des=np.zeros(self.nh, dtype=np.float32),
                kp=kp.copy(),
                kd=kd.copy(),
                tau_ff=np.zeros(self.nh, dtype=np.float32),
            )
            self.backend.write(cmd)
            self._pace()

    def _run_policy_state(self, name: str, st: FsmStateSpec) -> RunResult:
        _, session, runner = self._policies[name]
        return runner.run(st.duration_s, soft_start=False)

    def _damp_out(self, seconds: float = 1.0) -> None:
        with contextlib.suppress(Exception):
            kd = np.array([j.safe_kd for j in self.descriptor.joints], dtype=np.float32)
            cmd = JointCommand.damped(self.nh, kd=kd)
            for _ in range(int(seconds / self._dt)):
                self.backend.write(cmd)
                self._pace()

    def _pace(self) -> None:
        if getattr(self.backend, "advances_time", False):
            return
        if self._deadline is None:
            self._deadline = time.perf_counter()
        self._deadline += self._dt
        remaining = self._deadline - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)
        else:
            self._deadline = time.perf_counter()


def run_fsm(fsm_yaml: str | Path, backend: Backend | None = None) -> FsmResult:
    path = Path(fsm_yaml)
    spec = FsmSpec.load(path)
    return FsmRunner(spec, base_dir=path.parent, backend=backend).run()
