"""ONNX policy session: flat-obs inference with optional recurrent state and
observation normalization."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import onnxruntime as ort

from ..spec.manifest import PolicyManifest


class PolicySession:
    def __init__(
        self, manifest: PolicyManifest, onnx_path: str | Path, norm_dir: str | Path | None = None
    ):
        self.manifest = manifest
        self.session = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
        io = manifest.policy
        input_names = [i.name for i in self.session.get_inputs()]
        output_names = [o.name for o in self.session.get_outputs()]
        if io.input not in input_names:
            raise ValueError(
                f"manifest declares obs input '{io.input}' but the ONNX model "
                f"has inputs {input_names}"
            )
        if io.output not in output_names:
            raise ValueError(
                f"manifest declares action output '{io.output}' but the ONNX "
                f"model has outputs {output_names}"
            )
        self._state_specs = io.states()  # [(in_name, out_name, init_shape)]
        for s_in, _, _ in self._state_specs:
            if s_in not in input_names:
                raise ValueError(
                    f"manifest declares state input '{s_in}' but the ONNX "
                    f"model has inputs {input_names}"
                )
        if io.state_input is not None and not self._state_specs:
            raise ValueError("manifest declares a recurrent state input but no state_init shape")

        # Expected obs dim from the graph, if statically shaped.
        shape = self.session.get_inputs()[input_names.index(io.input)].shape
        dims = [d for d in shape if isinstance(d, int)]
        self.expected_obs_dim: int | None = dims[-1] if dims else None

        self._states: list[np.ndarray] = [
            np.zeros(shape, dtype=np.float32) for _, _, shape in self._state_specs
        ]

        self._mean: np.ndarray | None = None
        self._std: np.ndarray | None = None
        norm = manifest.normalization
        if norm.file:
            base = Path(norm_dir) if norm_dir is not None else Path(onnx_path).parent
            data = np.load(base / norm.file)
            self._mean = data["mean"].astype(np.float32).ravel()
            self._std = data["std"].astype(np.float32).ravel()

    def reset(self) -> None:
        self._states = [np.zeros(shape, dtype=np.float32) for _, _, shape in self._state_specs]

    def step(self, obs: np.ndarray) -> np.ndarray:
        obs = np.asarray(obs, dtype=np.float32).ravel()
        if self.expected_obs_dim is not None and obs.shape[0] != self.expected_obs_dim:
            raise ValueError(
                f"built observation has {obs.shape[0]} dims but the ONNX model "
                f"expects {self.expected_obs_dim} — the manifest observation "
                f"recipe does not match this network"
            )
        if self._mean is not None and self._std is not None:
            obs = (obs - self._mean) / np.maximum(self._std, 1e-6)
        clip = self.manifest.normalization.clip_obs
        if clip is not None:
            obs = np.clip(obs, -clip, clip)

        io = self.manifest.policy
        feed: dict[str, np.ndarray] = {io.input: _shape_for(self.session, io.input, obs)}
        outputs = [io.output]
        for (s_in, s_out, _), state in zip(self._state_specs, self._states, strict=True):
            feed[s_in] = state
            outputs.append(s_out)

        results = self.session.run(outputs, feed)
        action = np.asarray(results[0], dtype=np.float32).ravel()
        for i in range(len(self._state_specs)):
            self._states[i] = np.asarray(results[1 + i], dtype=np.float32)

        n = self.manifest.num_joints()
        if action.shape[0] != n:
            raise ValueError(
                f"policy produced {action.shape[0]} actions but manifest declares {n} joints"
            )
        clip_a = self.manifest.control.clip_actions
        if clip_a is not None:
            action = np.clip(action, clip_a[0], clip_a[1])
        return action


def _shape_for(session: ort.InferenceSession, input_name: str, flat: np.ndarray) -> np.ndarray:
    """Feed a flat vector as rank-1 or rank-2 [1, n] depending on the graph."""
    for inp in session.get_inputs():
        if inp.name == input_name:
            if len(inp.shape) == 2:
                return flat[None, :]
            return flat
    return flat
