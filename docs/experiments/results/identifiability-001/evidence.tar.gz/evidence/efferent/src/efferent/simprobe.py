"""efferent.simprobe — probe a simulator's controller against its own contract.

The doctor checks the policy network and the audit checks the observation
builder. This probes the third place deployment contracts break: the
CONTROLLER between actions and physics. The motivating bug class: a
simulator's action scaling multiplies rotation actions by a negative bound,
so a commanded +1 rotation realizes as a negative rotation. Nothing crashes;
closed-loop feedback diverges and the arm freezes on inverse-kinematics
failures the sim silently swallows.

Three checks, generalized from the probe that caught that bug in the wild:

1. **Unit-action direction/magnitude probe**: for each action dimension,
   command a unit (and a negative unit) action from a settled state, measure
   the realized target delta, and verify sign and magnitude against the
   controller config's declared bounds. A sign flip fails with the exact
   dimension and measured-vs-expected values.
2. **Silent-failure surfacing**: count controller-internal failures the sim
   hides (e.g. IK returning None while the controller holds its previous
   targets, presenting as a frozen arm).
3. **Config-contract echo**: print the resolved action mapping, bounds and
   normalization flags, because "I didn't know normalize_action=False
   bypassed scaling entirely" is itself a documented failure mode.

Simulators plug in via a small adapter (see efferent.sims.maniskill).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from .doctor import FAIL, PASS, WARN, DoctorReport


@dataclass
class ProbeDim:
    """One probeable action dimension."""

    index: int  # index within the probed controller's action slice
    label: str  # e.g. "pos_x", "rot_z"
    expected: float  # expected realized delta for a +unit action (signed)
    kind: str = ""  # "pos" | "rot" | other, for reporting only


@runtime_checkable
class SimAdapter(Protocol):
    """What a simulator integration must provide."""

    def contract(self) -> list[str]:
        """Human-readable lines describing the resolved controller contract."""
        ...

    def dims(self) -> list[ProbeDim]: ...

    def probe(self, dim: ProbeDim, sign: float) -> float:
        """Reset to a settled state, command sign*unit on this dimension,
        return the realized signed target delta along it."""
        ...

    def failure_count(self) -> int:
        """Silent controller-internal failures observed since construction."""
        ...

    def steps_taken(self) -> int: ...

    def close(self) -> None: ...


class SimProbeReport(DoctorReport):
    def __str__(self) -> str:  # same format, different header
        return super().__str__().replace("efferent doctor report", "efferent simprobe report", 1)


def run_probe(adapter: SimAdapter, mag_tol: float = 0.25) -> SimProbeReport:
    """Run all checks against a sim adapter. Never raises for contract
    violations - those become FAIL entries."""
    report = SimProbeReport()

    report.add("controller contract", PASS, "\n".join(adapter.contract()))

    dims = adapter.dims()
    flipped: list[str] = []
    off_scale: list[str] = []
    detail_lines: list[str] = []
    for d in dims:
        plus = adapter.probe(d, +1.0)
        minus = adapter.probe(d, -1.0)
        exp = d.expected
        line = (
            f"{d.label:8s} +1 -> {plus:+.4f} (expect {exp:+.4f}) | "
            f"-1 -> {minus:+.4f} (expect {-exp:+.4f})"
        )
        detail_lines.append(line)
        sign_ok = (plus * exp > 0) and (minus * -exp > 0)
        if not sign_ok:
            flipped.append(
                f"{d.label}: commanded +1 realized {plus:+.4f}, expected {exp:+.4f} - SIGN INVERTED"
                if plus * exp < 0
                else f"{d.label}: no/ambiguous response (+1 -> {plus:+.4f}, -1 -> {minus:+.4f})"
            )
            continue
        mag_err = max(abs(abs(plus) - abs(exp)), abs(abs(minus) - abs(exp))) / max(abs(exp), 1e-9)
        if mag_err > mag_tol:
            off_scale.append(
                f"{d.label}: magnitude off by {mag_err:.0%} "
                f"(realized {plus:+.4f} vs expected {exp:+.4f})"
            )

    if flipped:
        report.add(
            "unit-action direction probe",
            FAIL,
            "\n".join(flipped) + "\ncommanded actions realize with the WRONG SIGN - closed-loop "
            "control on these dimensions will diverge",
        )
    elif off_scale:
        report.add(
            "unit-action direction probe",
            WARN,
            "signs correct, magnitudes off:\n" + "\n".join(off_scale),
        )
    else:
        report.add(
            "unit-action direction probe",
            PASS,
            f"all {len(dims)} dimensions realize with correct sign and magnitude",
        )
    report.add("realized deltas", PASS, "\n".join(detail_lines))

    failures = adapter.failure_count()
    steps = max(adapter.steps_taken(), 1)
    if failures:
        report.add(
            "silent controller failures",
            WARN,
            f"{failures} silent internal failures in {steps} probe steps "
            f"(e.g. IK returned no solution and the controller held its "
            f"previous targets). A high rate on a real task presents as a "
            f"frozen arm - check reachability for this kinematic chain",
        )
    else:
        report.add("silent controller failures", PASS, f"0 in {steps} probe steps")

    return report


def _cli_missing_sim(name: str, exc: Exception) -> None:
    raise SystemExit(
        f"simulator integration '{name}' is unavailable: {exc}\n"
        f"install the optional dependency, e.g.: pip install efferent[maniskill]"
    )
