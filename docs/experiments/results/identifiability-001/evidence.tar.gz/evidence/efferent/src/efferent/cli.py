"""efferent CLI.

efferent inspect  <policy.onnx|.app>
efferent pack     <policy.onnx> --manifest m.yaml -o out.app [--embed]
efferent import   --from rl_sar --base base.yaml --config config.yaml -o out_dir
efferent validate <policy> --robot robot.yaml [--duration 5]
efferent run      <policy> --robot robot.yaml [--duration 10] [--dry-run]
                   [--command "0.5,0,0"] [--backend-param key=value ...]
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import yaml

from . import __version__
from .backends.base import load_backend
from .package import (
    embed_manifest,
    extract_manifest,
    load_descriptor,
    load_manifest,
    load_policy,
    pack,
)
from .runtime.loop import Runner
from .runtime.policy import PolicySession
from .spec.binding import Binding
from .types import Command


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="efferent")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("inspect", help="show what a policy file declares and expects")
    p.add_argument("policy")
    p.add_argument("--manifest", default=None)

    p = sub.add_parser("doctor", help="preflight checks: catch wiring bugs before the robot moves")
    p.add_argument("policy")
    p.add_argument("--manifest", default=None)
    p.add_argument("--robot", default=None, help="robot descriptor yaml (enables binding check)")
    p.add_argument(
        "--reference",
        default=None,
        help="npz with obs [T,D] + actions [T,A] recorded from the "
        "training framework, for replay divergence check",
    )

    p = sub.add_parser("audit", help="verify a deployment's obs pipeline against a logged run")
    p.add_argument("policy", help="policy .app/.onnx or bare manifest .yaml")
    p.add_argument(
        "--log",
        required=True,
        help="npz with obs/q/dq (+ optional quat/gyro/lin_vel/command/action/t)",
    )
    p.add_argument("--robot", default=None, help="robot descriptor (log arrays in hardware order)")
    p.add_argument("--manifest", default=None)
    p.add_argument("--tol", type=float, default=1e-3)
    p.add_argument(
        "--hook", default=None, help="python file executed first (registers custom obs terms)"
    )

    p = sub.add_parser(
        "fsm", help="run a declarative multi-policy sequence (damp/pose/policy states)"
    )
    p.add_argument("spec", help="fsm yaml (states, transitions, robot descriptor)")
    p.add_argument("--backend", default=None, help="override the descriptor backend id")
    p.add_argument(
        "--backend-param",
        action="append",
        default=[],
        help="override/add backend param, key=value (repeatable)",
    )

    p = sub.add_parser("simprobe", help="probe a simulator's controller against its own contract")
    p.add_argument("--sim", default="maniskill", choices=["maniskill"])
    p.add_argument("--env-id", required=True, help="e.g. PickCube-v1")
    p.add_argument("--control-mode", default="pd_ee_delta_pose")
    p.add_argument("--robot-uid", default=None)
    p.add_argument(
        "--controller",
        default=None,
        help="sub-controller key to probe (default: first EE controller)",
    )
    p.add_argument("--sim-backend", default="physx_cpu")

    p = sub.add_parser("pack", help="bundle onnx + manifest into a .app package")
    p.add_argument("onnx")
    p.add_argument("--manifest", required=True)
    p.add_argument("-o", "--out", required=True)
    p.add_argument("--extra", action="append", default=[])
    p.add_argument(
        "--embed",
        action="store_true",
        help="also embed the manifest into the packaged ONNX metadata",
    )

    p = sub.add_parser("import", help="generate manifest+descriptor from a training framework")
    p.add_argument("--from", dest="source", required=True, choices=["rl_sar", "isaaclab"])
    p.add_argument("--base", default=None, help="rl_sar base.yaml")
    p.add_argument("--config", default=None, help="rl_sar config.yaml")
    p.add_argument(
        "--env", default=None, help="isaaclab/mjlab params/env.yaml from the training run"
    )
    p.add_argument(
        "--joints",
        default=None,
        help="isaaclab: ordered joint names - a preset (g1_29dof, go2) "
        "or a file with one joint name per line",
    )
    p.add_argument("--robot-name", default=None)
    p.add_argument("-o", "--out-dir", required=True)

    for name, help_text in (
        ("validate", "run the policy against a simulator backend and report"),
        ("run", "run the policy on a robot backend"),
    ):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("policy")
        p.add_argument("--manifest", default=None)
        p.add_argument("--robot", required=True, help="robot descriptor yaml")
        p.add_argument("--duration", type=float, default=5.0)
        p.add_argument("--command", default=None, help="comma-separated command vector")
        p.add_argument("--backend", default=None, help="override descriptor backend id")
        p.add_argument(
            "--backend-param",
            action="append",
            default=[],
            help="override/add backend param, key=value (repeatable)",
        )
        p.add_argument(
            "--dry-run",
            action="store_true",
            help="full loop, but never send commands to the backend",
        )
        p.add_argument("--no-soft-start", action="store_true")
        p.add_argument(
            "--hook",
            default=None,
            help="python file executed before the run (e.g. to register custom observation terms)",
        )

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    return {
        "inspect": _cmd_inspect,
        "doctor": _cmd_doctor,
        "audit": _cmd_audit,
        "fsm": _cmd_fsm,
        "simprobe": _cmd_simprobe,
        "pack": _cmd_pack,
        "import": _cmd_import,
        "validate": _cmd_run,
        "run": _cmd_run,
    }[args.cmd](args)


def _cmd_audit(args: argparse.Namespace) -> int:
    if args.hook:
        _load_hook(args.hook)
    from .audit import audit

    report = audit(
        args.policy, log=args.log, robot=args.robot, manifest=args.manifest, tol=args.tol
    )
    print(report)
    return 0 if report.passed else 1


def _load_hook(path: str) -> None:
    import importlib.util

    spec = importlib.util.spec_from_file_location("efferent_hook", path)
    hook_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(hook_mod)


def _cmd_simprobe(args: argparse.Namespace) -> int:
    from .simprobe import run_probe

    if args.sim == "maniskill":
        try:
            from .sims.maniskill import ManiSkillAdapter

            adapter = ManiSkillAdapter(
                env_id=args.env_id,
                control_mode=args.control_mode,
                robot_uid=args.robot_uid,
                controller_key=args.controller,
                sim_backend=args.sim_backend,
            )
        except ImportError as e:
            print(f"ManiSkill integration unavailable: {e}")
            print("install with: pip install efferent[maniskill]")
            return 2
    else:  # unreachable via argparse choices
        print(f"unknown sim '{args.sim}'")
        return 2
    try:
        report = run_probe(adapter)
    finally:
        adapter.close()
    print(report)
    return 0 if report.passed else 1


def _cmd_fsm(args: argparse.Namespace) -> int:
    from .backends.base import load_backend as _lb
    from .fsm import FsmRunner, FsmSpec

    spec_path = Path(args.spec)
    spec = FsmSpec.load(spec_path)
    backend = None
    if args.backend or args.backend_param:
        descriptor = load_descriptor(
            p if (p := Path(spec.robot)).is_absolute() else spec_path.parent / spec.robot
        )
        backend_id = args.backend or descriptor.backend.id
        params = dict(descriptor.backend.params)
        for kv in args.backend_param:
            key, _, value = kv.partition("=")
            try:
                params[key] = json.loads(value)
            except json.JSONDecodeError:
                params[key] = value
        backend = _lb(backend_id, params)
    result = FsmRunner(spec, base_dir=spec_path.parent, backend=backend).run()
    print(f"sequence: {' -> '.join(result.sequence)}")
    if result.completed:
        print("[ok] sequence completed")
        return 0
    print(f"[STOPPED] {result.stop_reason}")
    return 2


def _cmd_doctor(args: argparse.Namespace) -> int:
    from .doctor import doctor

    report = doctor(args.policy, robot=args.robot, manifest=args.manifest, reference=args.reference)
    print(report)
    return 0 if report.passed else 1


# ---------------------------------------------------------------------------


def _cmd_inspect(args: argparse.Namespace) -> int:
    path = Path(args.policy)
    if path.suffix == ".onnx" and args.manifest is None and extract_manifest(path) is None:
        import onnxruntime as ort

        sess = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
        print(f"{path.name}: no efferent manifest (embedded or sidecar)")
        print("model I/O:")
        for i in sess.get_inputs():
            print(f"  input  {i.name}: {i.shape} {i.type}")
        for o in sess.get_outputs():
            print(f"  output {o.name}: {o.shape} {o.type}")
        print(
            "next step: write a manifest (efferent import, or by hand) "
            "describing the observation layout."
        )
        return 1

    manifest, onnx_path, _ = load_policy(args.policy, args.manifest)
    obs_dims = []
    for t in manifest.observation:
        obs_dims.append(f"{t.term}" + (f" x{t.history}" if t.history > 1 else ""))
    print(f"policy '{manifest.name}' (spec v{manifest.efferent})")
    print(f"  file:        {onnx_path}")
    print(f"  joints:      {manifest.num_joints()} (policy order): {manifest.joint_names}")
    print(f"  action:      {manifest.control.action_type} @ {manifest.control.rate_hz} Hz")
    print(f"  observation: {' + '.join(obs_dims)}")
    if manifest.provenance.trained_in:
        print(f"  provenance:  trained in {manifest.provenance.trained_in}")
    return 0


def _cmd_pack(args: argparse.Namespace) -> int:
    manifest = load_manifest(args.manifest)
    onnx_path = Path(args.onnx)
    if args.embed:
        onnx_path = embed_manifest(onnx_path, manifest)
    out = pack(manifest, onnx_path, args.out, extras=args.extra)
    print(f"packed -> {out}")
    return 0


def _cmd_import(args: argparse.Namespace) -> int:
    if args.source == "rl_sar":
        if not (args.base and args.config):
            print("rl_sar import requires --base and --config")
            return 2
        from .importers.rl_sar import import_rl_sar

        manifest, descriptor = import_rl_sar(args.base, args.config)
    else:  # isaaclab
        if not (args.env and args.joints):
            print("isaaclab import requires --env and --joints (preset name or file)")
            return 2
        from .importers.isaaclab import import_isaaclab
        from .importers.presets import PRESETS

        if args.joints in PRESETS:
            joints = PRESETS[args.joints]
            robot_name = args.robot_name or args.joints
        else:
            joints = [
                line.strip()
                for line in Path(args.joints).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            robot_name = args.robot_name or "robot"
        manifest, descriptor = import_isaaclab(args.env, joints, robot_name=robot_name)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "manifest.yaml").write_text(
        yaml.safe_dump(manifest.model_dump(mode="json"), sort_keys=False), encoding="utf-8"
    )
    (out / f"{descriptor.robot}.robot.yaml").write_text(
        yaml.safe_dump(descriptor.model_dump(mode="json"), sort_keys=False), encoding="utf-8"
    )
    print(f"wrote {out / 'manifest.yaml'}")
    print(f"wrote {out / (descriptor.robot + '.robot.yaml')}")
    print("note: review backend id/params in the descriptor before running on hardware.")
    return 0


def _cmd_run(args: argparse.Namespace) -> int:
    if args.hook:
        _load_hook(args.hook)

    manifest, onnx_path, workdir = load_policy(args.policy, args.manifest)
    descriptor = load_descriptor(args.robot)

    backend_id = args.backend or descriptor.backend.id
    params = dict(descriptor.backend.params)
    for kv in args.backend_param:
        key, _, value = kv.partition("=")
        try:
            params[key] = json.loads(value)
        except json.JSONDecodeError:
            params[key] = value

    binding = Binding(manifest, descriptor)  # validates before anything moves
    policy = PolicySession(manifest, onnx_path, norm_dir=workdir)
    backend = load_backend(backend_id, params)

    command_source = None
    if args.command:
        vec = np.array([float(x) for x in args.command.split(",")], dtype=np.float32)
        command_source = lambda t: Command(names=[f"c{i}" for i in range(len(vec))], values=vec)  # noqa: E731

    runner = Runner(binding, policy, backend, command_source=command_source, dry_run=args.dry_run)
    result = runner.run(args.duration, soft_start=not args.no_soft_start)

    status = "ESTOP" if result.estopped else "ok"
    print(f"[{status}] {result.steps} policy steps in {result.duration_s:.2f}s wall time")
    if result.estopped:
        print(f"  reason: {result.estop_reason}")
        return 2
    if result.final_state is not None:
        q_p = binding.to_policy(result.final_state.q)
        err = np.abs(q_p - binding.default_pose_p)
        print(
            f"  final joint error vs default pose: mean {err.mean():.4f} rad, "
            f"max {err.max():.4f} rad"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
