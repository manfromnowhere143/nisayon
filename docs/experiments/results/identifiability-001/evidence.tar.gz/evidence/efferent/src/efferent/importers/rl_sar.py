"""Importer: rl_sar (fan-ziqi/rl_sar) config pair -> efferent manifest + descriptor.

rl_sar splits deployment into `base.yaml` (hardware truth, physical joint
order) and `<CONFIG>/config.yaml` (policy contract, policy joint order, with
an integer joint_mapping where mapping[policy_i] = hardware_index). Both map
losslessly onto efferent's manifest/descriptor split — and the fragile index
array becomes derived-by-name on our side.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..spec.descriptor import BackendRef, HwJoint, RobotDescriptor
from ..spec.manifest import (
    ControlSpec,
    GainSpec,
    JointSpec,
    NormalizationSpec,
    ObsTerm,
    PolicyIO,
    PolicyManifest,
    Provenance,
)

# rl_sar observation term -> (efferent term, name of its scale key)
_TERM_MAP = {
    "lin_vel": ("base_lin_vel", "lin_vel_scale"),
    "ang_vel": ("base_ang_vel", "ang_vel_scale"),
    "gravity_vec": ("projected_gravity", None),
    "commands": ("command", "commands_scale"),
    "dof_pos": ("joint_pos_rel", "dof_pos_scale"),
    "dof_vel": ("joint_vel", "dof_vel_scale"),
    "actions": ("last_action", None),
}


def import_rl_sar(
    base_yaml: str | Path,
    config_yaml: str | Path,
    backend: BackendRef | None = None,
    policy_file: str = "policy.onnx",
) -> tuple[PolicyManifest, RobotDescriptor]:
    base = _single_value(yaml.safe_load(Path(base_yaml).read_text(encoding="utf-8")))
    cfg_key, cfg = _single_entry(yaml.safe_load(Path(config_yaml).read_text(encoding="utf-8")))

    if cfg.get("observations_history"):
        raise NotImplementedError(
            "rl_sar observations_history import is not supported yet — "
            "declare per-term history in the manifest by hand"
        )

    hw_names: list[str] = base["joint_names"]
    mapping: list[int] = cfg["joint_mapping"]
    policy_names = [hw_names[i] for i in mapping]
    defaults = cfg["default_dof_pos"]

    obs_terms: list[ObsTerm] = []
    for term in cfg["observations"]:
        if term not in _TERM_MAP:
            raise ValueError(
                f"rl_sar observation term '{term}' has no efferent mapping "
                f"(known: {sorted(_TERM_MAP)})"
            )
        ap_term, scale_key = _TERM_MAP[term]
        scale = cfg.get(scale_key, 1.0) if scale_key else 1.0
        kwargs: dict = {"term": ap_term, "scale": scale}
        if ap_term == "command":
            kwargs["names"] = ["vel_x", "vel_y", "yaw_rate"]
        obs_terms.append(ObsTerm(**kwargs))

    clip_lo = cfg.get("clip_actions_lower")
    clip_hi = cfg.get("clip_actions_upper")
    clip_actions = None
    if clip_lo is not None and clip_hi is not None:
        clip_actions = (float(min(clip_lo)), float(max(clip_hi)))

    dt = float(base.get("dt", 0.005))
    decimation = int(base.get("decimation", 4))

    manifest = PolicyManifest(
        name=cfg_key.replace("/", "-"),
        policy=PolicyIO(file=policy_file),
        control=ControlSpec(
            rate_hz=1.0 / (dt * decimation),
            action_type="joint_position_delta",
            action_scale=cfg["action_scale"],
            clip_actions=clip_actions,
            gains=GainSpec(kp=cfg["rl_kp"], kd=cfg["rl_kd"]),
        ),
        joints=[
            JointSpec(name=n, default=float(d)) for n, d in zip(policy_names, defaults, strict=True)
        ],
        observation=obs_terms,
        normalization=NormalizationSpec(clip_obs=cfg.get("clip_obs")),
        provenance=Provenance(trained_in="unknown", repo="imported-from-rl_sar"),
    )

    hw_torque = base.get("torque_limits", [None] * len(hw_names))
    hw_kp = base.get("fixed_kp", [40.0] * len(hw_names))
    hw_kd = base.get("fixed_kd", [2.0] * len(hw_names))
    descriptor = RobotDescriptor(
        robot=cfg_key.split("/")[0],
        backend=backend or BackendRef(id="mock", params={}),
        joints=[
            HwJoint(
                name=n,
                torque_limit=float(hw_torque[i]) if hw_torque[i] is not None else None,
                safe_kp=float(hw_kp[i]),
                safe_kd=float(hw_kd[i]),
            )
            for i, n in enumerate(hw_names)
        ],
    )
    return manifest, descriptor


def _single_value(doc: dict) -> dict:
    return _single_entry(doc)[1]


def _single_entry(doc: dict) -> tuple[str, dict]:
    if not isinstance(doc, dict) or len(doc) != 1:
        raise ValueError(
            "expected an rl_sar-style YAML with exactly one top-level key (the robot/config name)"
        )
    return next(iter(doc.items()))
