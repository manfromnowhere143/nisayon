"""efferent.audit — verify a deployment's observation pipeline against a log.

The frame/order/scale bugs that fell robots live in the OBS BUILDER — the
code between sensors and the network — which no amount of probing the network
alone can check. The audit closes that gap: given a log of raw states plus
the obs vectors the deployment pipeline actually built from them, it rebuilds
every observation term from the raw states (using efferent's obs builder as
the reference implementation of the manifest's semantics) and diffs PER TERM.

For mismatched terms it goes further and tests the classic hypotheses:
  - wrong frame (world-frame angular/linear velocity where body frame is
    expected — the rl_sar #88 / #183 bug class),
  - missing or wrong scale factor,
  - permuted joint ordering (reported with the observed permutation).

Log format (npz):
  required: obs [T, D]   — obs vectors your pipeline produced
            q   [T, nh]  — joint positions (hardware order if a robot
                           descriptor is given, else manifest/policy order)
            dq  [T, nh]  — joint velocities
  optional: quat [T, 4] (wxyz), gyro [T, 3], acc [T, 3], lin_vel [T, 3],
            tau [T, nh], command [T, C], action [T, n] (applied actions;
            used as last_action, shifted by one), t [T] (seconds)

Usage:
    efferent audit policy.app --log deploy_log.npz [--robot robot.yaml]
or  report = efferent.audit("manifest.yaml", log="deploy_log.npz")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .package import load_descriptor, load_manifest, load_policy
from .runtime.obs import ObsBuilder, quat_rotate_inverse
from .spec.binding import Binding
from .spec.descriptor import BackendRef, HwJoint, RobotDescriptor
from .types import Command, RobotState

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"


@dataclass
class TermResult:
    term: str
    dims: tuple[int, int]  # [start, end) in the obs vector
    max_err: float
    mean_err: float
    status: str
    hint: str = ""


@dataclass
class AuditReport:
    terms: list[TermResult] = field(default_factory=list)
    steps: int = 0
    notes: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(t.status != FAIL for t in self.terms)

    def __str__(self) -> str:
        icon = {PASS: "[ok]  ", WARN: "[warn]", FAIL: "[FAIL]"}
        lines = [f"efferent audit report ({self.steps} logged steps)", "-" * 60]
        for t in self.terms:
            lines.append(
                f"{icon[t.status]} {t.term:24s} dims {t.dims[0]:>3}..{t.dims[1] - 1:<3} "
                f"max|err| {t.max_err:.4g}"
            )
            if t.hint:
                for h in t.hint.splitlines():
                    lines.append(f"        {h}")
        for n in self.notes:
            lines.append(f"note: {n}")
        lines.append("-" * 60)
        n_fail = sum(1 for t in self.terms if t.status == FAIL)
        lines.append(
            f"verdict: {'PASS' if self.passed else 'FAIL'} "
            f"({len(self.terms)} terms, {n_fail} mismatched)"
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------


def audit(
    policy: str | Path,
    log: str | Path,
    robot: str | Path | None = None,
    manifest: str | Path | None = None,
    tol: float = 1e-3,
) -> AuditReport:
    policy = Path(policy)
    if policy.suffix in (".yaml", ".yml"):
        mf = load_manifest(policy)
    else:
        mf, _, _ = load_policy(policy, manifest)

    if robot is not None:
        descriptor = load_descriptor(robot)
    else:  # identity: log arrays already in policy joint order
        descriptor = RobotDescriptor(
            robot="audit-identity",
            backend=BackendRef(id="mock", params={}),
            joints=[HwJoint(name=j.name) for j in mf.joints],
        )
    binding = Binding(mf, descriptor)

    data = np.load(log)
    for key in ("obs", "q", "dq"):
        if key not in data:
            raise ValueError(
                f"log is missing required array '{key}' "
                f"(required: obs, q, dq; found: {sorted(data.files)})"
            )
    obs_log = np.asarray(data["obs"], dtype=np.float32)
    T = obs_log.shape[0]
    n = mf.num_joints()

    def opt(key: str):
        return np.asarray(data[key], dtype=np.float32) if key in data else None

    q, dq = np.asarray(data["q"], np.float32), np.asarray(data["dq"], np.float32)
    quat, gyro, acc = opt("quat"), opt("gyro"), opt("acc")
    lin_vel, tau, command, action, times = (
        opt("lin_vel"),
        opt("tau"),
        opt("command"),
        opt("action"),
        opt("t"),
    )

    report = AuditReport(steps=T)
    period = 1.0 / mf.control.rate_hz

    builder = ObsBuilder(binding)
    rebuilt = np.zeros_like(obs_log)
    cmd_names = next(
        (t.names for t in mf.observation if t.term == "command" and t.names),
        ["c0", "c1", "c2"],
    )
    for t_i in range(T):
        state = RobotState(
            q=q[t_i],
            dq=dq[t_i],
            tau=tau[t_i] if tau is not None else None,
            quat=quat[t_i] if quat is not None else None,
            gyro=gyro[t_i] if gyro is not None else None,
            acc=acc[t_i] if acc is not None else None,
            lin_vel=lin_vel[t_i] if lin_vel is not None else None,
        )
        if command is not None:
            cmd = Command(names=list(cmd_names), values=command[t_i])
        else:
            cmd = Command(names=list(cmd_names), values=np.zeros(len(cmd_names), np.float32))
        last_action = (
            action[t_i - 1] if (action is not None and t_i > 0) else np.zeros(n, np.float32)
        )
        tt = float(times[t_i]) if times is not None else t_i * period
        vec = builder.build(state, last_action, cmd, tt)
        if vec.shape[0] != obs_log.shape[1]:
            raise ValueError(
                f"manifest recipe produces {vec.shape[0]} dims but the logged "
                f"obs have {obs_log.shape[1]} - wrong manifest for this log?"
            )
        rebuilt[t_i] = vec

    if command is None and any(t.term == "command" for t in mf.observation):
        report.notes.append(
            "no 'command' array in the log - command term compared against "
            "zeros; a mismatch there may just mean nonzero commands were sent"
        )
    if action is None and any(t.term == "last_action" for t in mf.observation):
        report.notes.append(
            "no 'action' array in the log - last_action compared against "
            "zeros; log the applied actions to check this term"
        )

    # per-term layout from the builder's resolved dims
    off = 0
    for term, dim_ in zip(mf.observation, builder._dims, strict=True):
        width = dim_ * term.history  # type: ignore[operator]
        sl = slice(off, off + width)
        diff = np.abs(obs_log[:, sl] - rebuilt[:, sl])
        max_err, mean_err = float(diff.max()), float(diff.mean())
        status = PASS if max_err <= tol else FAIL
        hint = ""
        if status == FAIL:
            hint = _diagnose(
                term,
                obs_log[:, sl],
                rebuilt[:, sl],
                binding,
                quat,
                gyro,
                lin_vel,
                tol,
            )
        report.terms.append(
            TermResult(term.term, (off, off + width), max_err, mean_err, status, hint)
        )
        off += width
    return report


# -- mismatch hypothesis tests ----------------------------------------------


def _diagnose(
    term_spec,
    logged: np.ndarray,
    rebuilt: np.ndarray,
    binding: Binding,
    quat: np.ndarray | None,
    gyro: np.ndarray | None,
    lin_vel: np.ndarray | None,
    tol: float,
) -> str:
    term = term_spec.term
    term_scale = (
        np.asarray(term_spec.scale, dtype=np.float64)
        if isinstance(term_spec.scale, list)
        else float(term_spec.scale)
    )
    hints: list[str] = []

    # Hypothesis: wrong frame (world vs body) for 3-dim base-frame terms.
    if term in ("base_ang_vel", "base_lin_vel") and quat is not None:
        src = gyro if term == "base_ang_vel" else lin_vel
        if src is not None:
            world = np.stack([_rotate_to_world(quat[i], src[i]) for i in range(len(src))])
            if np.abs(logged - world * term_scale).max() <= max(tol, 1e-2):
                return (
                    f"logged values match the WORLD-frame {term.split('_', 1)[1]} "
                    f"- training expects the BODY frame "
                    f"(apply quat_rotate_inverse before building the obs)"
                )

    # Hypothesis: one-step delay (stale obs / off-by-one logging).
    if logged.shape[0] >= 5:
        lag_err = float(np.abs(logged[1:] - rebuilt[:-1]).max())
        if lag_err <= max(tol, 1e-3):
            return (
                "logged values equal the PREVIOUS step's expected values - "
                "one-step delay (stale observation or off-by-one in the "
                "logging/control loop)"
            )

    # Hypothesis: constant scale factor missing or wrong.
    k = _fit_scale(logged, rebuilt)
    if k is not None and abs(k - 1.0) > 0.01:
        if abs(k + 1.0) <= 0.02:
            hints.append(
                "logged = -rebuilt: SIGN FLIP - axis convention or "
                "quaternion-conjugate mistake in this term"
            )
        elif abs(k - 180.0 / np.pi) <= 0.6:
            hints.append(
                f"logged = rebuilt x {k:.4g} (~57.2958 = 180/pi): this term "
                f"is in DEGREES but training expects RADIANS"
            )
        elif abs(k - np.pi / 180.0) <= 2e-4:
            hints.append(
                f"logged = rebuilt x {k:.4g} (~pi/180): this term is in "
                f"RADIANS-per-degree scaling - inverse degree/radian mixup"
            )
        else:
            hints.append(
                f"logged = rebuilt x {k:.4g} - looks like a scale mismatch "
                f"(missing or extra obs scale factor of {k:.4g})"
            )

    # Hypothesis: permuted columns (joint-indexed terms).
    if logged.shape[1] >= 3 and logged.shape[0] >= 10:
        mapping = _column_permutation(logged, rebuilt)
        if mapping is not None:
            hints.append(
                f"logged columns are a PERMUTATION of the expected ones - "
                f"observed mapping (logged column -> expected column): {mapping}"
            )

    return "\n".join(hints) if hints else "no standard hypothesis fits - inspect this term manually"


def _rotate_to_world(quat_wxyz: np.ndarray, v_body: np.ndarray) -> np.ndarray:
    """Inverse of quat_rotate_inverse: body-frame vector -> world frame."""
    w, x, y, z = quat_wxyz
    conj = np.array([w, -x, -y, -z])
    return quat_rotate_inverse(conj, np.asarray(v_body, dtype=np.float64))


def _fit_scale(logged: np.ndarray, rebuilt: np.ndarray) -> float | None:
    """Best single scale factor k with logged ~= rebuilt * k, if one fits."""
    mask = np.abs(rebuilt) > 1e-6
    if mask.sum() < max(10, logged.size // 20):
        return None
    ratios = logged[mask] / rebuilt[mask]
    k = float(np.median(ratios))
    if not np.isfinite(k):
        return None
    resid = np.abs(logged[mask] - rebuilt[mask] * k)
    ref = np.abs(logged[mask]).mean() + 1e-9
    return k if resid.max() <= max(0.02 * ref, 1e-4) else None


def _column_permutation(logged: np.ndarray, rebuilt: np.ndarray) -> list[int] | None:
    """If each logged column matches a distinct rebuilt column (possibly not
    its own), return the mapping; None if no clean bijection exists."""
    d = logged.shape[1]
    mapping = []
    for i in range(d):
        errs = np.abs(rebuilt - logged[:, i : i + 1]).mean(axis=0)
        j = int(np.argmin(errs))
        spread = np.abs(logged[:, i]).mean() + 1e-9
        if errs[j] > 0.05 * spread:
            return None
        mapping.append(j)
    if len(set(mapping)) != d or mapping == list(range(d)):
        return None
    return mapping
