"""Robot descriptor: hardware truth for one robot.

Joint order here is the HARDWARE order (the order the SDK/firmware speaks).
Limits declared here are authoritative — the safety layer enforces them over
anything a policy manifest claims.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class HwJoint(StrictModel):
    name: str
    torque_limit: float | None = None
    pos_limit: tuple[float, float] | None = None
    vel_limit: float | None = None
    # Gains used outside RL mode (damped stand, soft-start interpolation).
    safe_kp: float = 40.0
    safe_kd: float = 2.0


class BackendRef(StrictModel):
    id: str  # entry-point name, e.g. "mujoco", "unitree-dds"
    params: dict = Field(default_factory=dict)


class SensorSpec(StrictModel):
    model_config = ConfigDict(extra="allow")
    imu: str | None = "base"
    joint_encoders: bool = True


class StartupSpec(StrictModel):
    mode: str = "damped"
    interp_to_default_s: float = 3.0


class RobotDescriptor(StrictModel):
    robot: str
    backend: BackendRef
    joints: list[HwJoint]
    sensors: SensorSpec = Field(default_factory=SensorSpec)
    startup: StartupSpec = Field(default_factory=StartupSpec)

    @model_validator(mode="after")
    def _validate(self) -> RobotDescriptor:
        names = [j.name for j in self.joints]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ValueError(f"duplicate joint names in descriptor: {sorted(dupes)}")
        if not self.joints:
            raise ValueError("descriptor must declare at least one joint")
        return self

    @property
    def joint_names(self) -> list[str]:
        return [j.name for j in self.joints]

    def num_joints(self) -> int:
        return len(self.joints)
