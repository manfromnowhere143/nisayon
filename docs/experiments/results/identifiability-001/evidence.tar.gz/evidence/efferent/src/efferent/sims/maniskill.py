"""ManiSkill adapter for the simprobe (optional dependency).

Probes ManiSkill end-effector controllers (PDEEPos / PDEEPose family) on the
CPU sim, where the controller maintains an explicit target pose we can read
back. Quaternion math is done locally rather than through ManiSkill's
rotation utilities to stay robust across versions.
"""

from __future__ import annotations

import numpy as np

from ..simprobe import ProbeDim


def _quat_mul(a, b):  # wxyz, torch tensors [*, 4]
    import torch

    aw, ax, ay, az = a.unbind(-1)
    bw, bx, by, bz = b.unbind(-1)
    return torch.stack(
        [
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ],
        dim=-1,
    )


def _quat_conj(q):
    import torch

    w, x, y, z = q.unbind(-1)
    return torch.stack([w, -x, -y, -z], dim=-1)


def _quat_to_axis_angle(q):
    """wxyz unit quaternion -> axis-angle vector [*, 3]."""
    import torch

    q = q / torch.linalg.norm(q, dim=-1, keepdim=True)
    # canonicalize the double cover (q and -q are the same rotation) so the
    # recovered angle is in [-pi, pi] instead of wrapping to 2*pi - angle
    q = torch.where(q[..., :1] < 0, -q, q)
    w = q[..., 0].clamp(-1.0, 1.0)
    v = q[..., 1:]
    vnorm = torch.linalg.norm(v, dim=-1, keepdim=True)
    angle = 2.0 * torch.atan2(vnorm.squeeze(-1), w)
    axis = torch.where(vnorm > 1e-9, v / vnorm.clamp(min=1e-12), torch.zeros_like(v))
    return axis * angle.unsqueeze(-1)


class ManiSkillAdapter:
    def __init__(
        self,
        env_id: str,
        control_mode: str = "pd_ee_delta_pose",
        robot_uid: str | None = None,
        controller_key: str | None = None,
        sim_backend: str = "physx_cpu",
        settle_steps: int = 3,
        seed: int = 0,
    ):
        try:
            import gymnasium as gym
            import mani_skill.envs  # noqa: F401  (registers environments)
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "the ManiSkill probe needs mani_skill: pip install efferent[maniskill]"
            ) from e

        kwargs: dict = dict(
            num_envs=1,
            obs_mode="state",
            control_mode=control_mode,
            sim_backend=sim_backend,
        )
        if robot_uid:
            kwargs["robot_uids"] = robot_uid
        self.env = gym.make(env_id, **kwargs)
        self.env_id = env_id
        self.settle_steps = settle_steps
        self.seed = seed
        self._steps = 0
        self._ik_failures = 0

        agent = self.env.unwrapped.agent
        composite = agent.controller
        subs = getattr(composite, "controllers", None)
        if subs is None:  # a single bare controller
            subs = {"controller": composite}
        self._slices: dict[str, tuple[int, int]] = {}
        off = 0
        for name, c in subs.items():
            n = int(np.prod(c.single_action_space.shape))
            self._slices[name] = (off, off + n)
            off += n
        self._total_dof = off

        if controller_key is None:
            for name, c in subs.items():
                if type(c).__name__.startswith(("PDEEPose", "PDEEPos")):
                    controller_key = name
                    break
        if controller_key is None or controller_key not in subs:
            raise ValueError(
                f"no PDEEPos/PDEEPose controller found in {list(subs)}; "
                f"pass controller_key explicitly (v1 probes EE controllers only)"
            )
        self.key = controller_key
        self.ctrl = subs[controller_key]
        self._subs = subs

        # Count IK calls that return no solution: the controller silently
        # holds its previous targets in that case.
        kin = self.ctrl.kinematics
        orig = kin.compute_ik

        def counting_ik(*a, **k):
            out = orig(*a, **k)
            if out is None:
                self._ik_failures += 1
            return out

        kin.compute_ik = counting_ik

        cfg = self.ctrl.config
        self.pos_bounds = np.broadcast_to(np.asarray(cfg.pos_upper, dtype=np.float64), (3,))
        self.rot_bounds = (
            np.abs(np.broadcast_to(np.asarray(cfg.rot_upper, dtype=np.float64), (3,)))
            if hasattr(cfg, "rot_upper")
            else None
        )
        self.normalize = bool(getattr(cfg, "normalize_action", True))

    # -- SimAdapter ------------------------------------------------------

    def contract(self) -> list[str]:
        cfg = self.ctrl.config
        start, end = self._slices[self.key]
        lines = [
            f"env {self.env_id} | control_mode of probed controller: '{self.key}' "
            f"({type(self.ctrl).__name__}), action dims [{start}..{end - 1}] of {self._total_dof}",
            f"frame={getattr(cfg, 'frame', '?')} use_delta={getattr(cfg, 'use_delta', '?')} "
            f"use_target={getattr(cfg, 'use_target', '?')} normalize_action={self.normalize}",
            f"pos bounds {self.pos_bounds.tolist()}"
            + (f" | rot bounds {self.rot_bounds.tolist()}" if self.rot_bounds is not None else ""),
        ]
        if not self.normalize:
            lines.append(
                "normalize_action=False: actions BYPASS the scaling path and are "
                "used raw (clipped to the action space) - the probe commands "
                "bound-sized raw actions accordingly"
            )
        others = [
            f"{n}: {type(c).__name__} dof {self._slices[n][1] - self._slices[n][0]}"
            for n, c in self._subs.items()
            if n != self.key
        ]
        if others:
            lines.append("other controllers: " + "; ".join(others))
        return lines

    def dims(self) -> list[ProbeDim]:
        out = [
            ProbeDim(index=i, label=f"pos_{ax}", expected=float(self.pos_bounds[i]), kind="pos")
            for i, ax in enumerate("xyz")
        ]
        if self.rot_bounds is not None:
            out += [
                ProbeDim(
                    index=3 + i,
                    label=f"rot_{ax}",
                    expected=float(self.rot_bounds[i]),
                    kind="rot",
                )
                for i, ax in enumerate("xyz")
            ]
        return out

    def probe(self, dim: ProbeDim, sign: float) -> float:
        import torch

        self.env.reset(seed=self.seed)
        zero = np.zeros(self._total_dof, dtype=np.float32)
        for _ in range(self.settle_steps):
            self.env.step(zero)
            self._steps += 1

        cfg = self.ctrl.config
        if getattr(cfg, "use_target", False) and self.ctrl._target_pose is not None:
            prev = self.ctrl._target_pose
        else:
            prev = self.ctrl.ee_pose_at_base
        prev_p = prev.p.clone()
        prev_q = prev.q.clone()

        if self.normalize:
            unit = 1.0
        else:
            unit = float(
                self.pos_bounds[dim.index] if dim.kind == "pos" else self.rot_bounds[dim.index - 3]
            )
        start, _ = self._slices[self.key]
        action = zero.copy()
        action[start + dim.index] = sign * unit
        self.env.step(action)
        self._steps += 1

        new = self.ctrl._target_pose
        if new is None:
            return 0.0
        if dim.kind == "pos":
            return float((new.p - prev_p)[0, dim.index].item())
        # rotation: recover the delta quaternion per the configured frame
        frame = str(getattr(cfg, "frame", "root_aligned_body_rotation"))
        if "body_aligned_body_rotation" in frame:
            q_delta = _quat_mul(_quat_conj(prev_q), new.q)
        else:  # root_aligned_body_rotation (default)
            q_delta = _quat_mul(new.q, _quat_conj(prev_q))
        aa = _quat_to_axis_angle(torch.as_tensor(q_delta))
        return float(aa[0, dim.index - 3].item())

    def failure_count(self) -> int:
        return self._ik_failures

    def steps_taken(self) -> int:
        return self._steps

    def close(self) -> None:
        self.env.close()
