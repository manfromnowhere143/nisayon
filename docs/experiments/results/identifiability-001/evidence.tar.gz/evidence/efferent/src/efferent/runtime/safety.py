"""Safety layer: sits between the policy and the backend on every tick.

Descriptor limits are authoritative. Everything here operates in hardware
joint order on the final JointCommand.
"""

from __future__ import annotations

import numpy as np

from ..spec.binding import Binding
from ..types import JointCommand


class ActionRateLimiter:
    """Clamps per-step change of the raw policy action (policy order)."""

    def __init__(self, max_rate: float | None):
        self.max_rate = max_rate
        self._last: np.ndarray | None = None

    def reset(self) -> None:
        self._last = None

    def __call__(self, action: np.ndarray) -> np.ndarray:
        if self.max_rate is None:
            return action
        if self._last is None:
            self._last = np.zeros_like(action)
        limited = np.clip(action, self._last - self.max_rate, self._last + self.max_rate)
        self._last = limited
        return limited


class CommandClamp:
    """Enforces hardware position and torque limits on the outgoing command."""

    def __init__(self, binding: Binding):
        self.b = binding

    def __call__(self, cmd: JointCommand, q_now: np.ndarray) -> JointCommand:
        b = self.b
        cmd.q_des = np.clip(cmd.q_des, b.pos_lo_h, b.pos_hi_h)
        finite = np.isfinite(b.torque_lim_h)
        if finite.any():
            cmd.tau_ff = np.clip(cmd.tau_ff, -b.torque_lim_h, b.torque_lim_h)
            # Cap the torque the PD terms could produce at the current state:
            # scale kp down where kp*|q_des - q| alone would exceed the limit.
            err = np.abs(cmd.q_des - q_now)
            with np.errstate(divide="ignore", invalid="ignore"):
                pd_tau = cmd.kp * err
                over = finite & (pd_tau > b.torque_lim_h)
                if over.any():
                    cmd.kp = np.where(over, b.torque_lim_h / np.maximum(err, 1e-6), cmd.kp)
        return cmd


class EnvelopeError(RuntimeError):
    """The robot's state is outside the policy's declared start envelope —
    the handoff is refused before any policy command is sent."""


def check_start_envelope(binding: Binding, state) -> list[str]:
    """Returns human-readable violations of the manifest's start envelope
    for the given robot state (empty list = safe to hand over)."""
    env = binding.manifest.envelope
    if env is None:
        return []
    violations: list[str] = []
    expected = np.asarray(
        env.expected_pose if env.expected_pose is not None else binding.manifest.default_pose,
        dtype=np.float64,
    )
    q_p = binding.to_policy(np.asarray(state.q, dtype=np.float64))
    err = np.abs(q_p - expected)
    for i in np.flatnonzero(err > env.joint_pos_tol):
        violations.append(
            f"joint '{binding.manifest.joint_names[int(i)]}' at "
            f"{q_p[int(i)]:+.3f} rad, policy expects {expected[int(i)]:+.3f} "
            f"(tol {env.joint_pos_tol})"
        )
    dq_p = np.abs(binding.to_policy(np.asarray(state.dq, dtype=np.float64)))
    for i in np.flatnonzero(dq_p > env.max_joint_vel):
        violations.append(
            f"joint '{binding.manifest.joint_names[int(i)]}' moving at "
            f"{dq_p[int(i)]:.2f} rad/s (max {env.max_joint_vel})"
        )
    if env.max_tilt is not None and state.quat is not None:
        from .obs import quat_rotate_inverse

        g_b = quat_rotate_inverse(
            np.asarray(state.quat, dtype=np.float64), np.array([0.0, 0.0, -1.0])
        )
        tilt = float(np.arccos(np.clip(-g_b[2], -1.0, 1.0)))
        if tilt > env.max_tilt:
            violations.append(f"base tilted {tilt:.2f} rad from upright (max {env.max_tilt})")
    return violations


class Watchdog:
    """Trips when the control loop or the robot state stream stalls."""

    def __init__(self, period_s: float, missed_ticks: int = 10):
        self.limit = period_s * missed_ticks
        self._last: float | None = None
        self.tripped = False

    def reset(self) -> None:
        self._last = None
        self.tripped = False

    def feed(self, now: float) -> bool:
        """Returns True if the watchdog trips at this feed."""
        if self._last is not None and (now - self._last) > self.limit:
            self.tripped = True
        self._last = now
        return self.tripped
