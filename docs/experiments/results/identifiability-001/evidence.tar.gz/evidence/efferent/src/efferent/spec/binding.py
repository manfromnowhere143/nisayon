"""Name-based binding between a policy manifest and a robot descriptor.

This is the load-bearing safety idea of efferent: the hand-maintained
integer `joint_mapping` arrays that deployment repos warn about become a
derived, validated artifact. A wrong or missing joint name is a startup
error here — never a fallen robot.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .descriptor import RobotDescriptor
from .manifest import PolicyManifest


class BindingError(ValueError):
    """Manifest and descriptor cannot be safely joined."""


@dataclass
class Binding:
    """Resolved join between one manifest and one descriptor.

    Index convention: arrays named *_p are in policy joint order, *_h in
    hardware joint order. `p2h[i]` is the hardware index of policy joint i.
    """

    manifest: PolicyManifest
    descriptor: RobotDescriptor
    p2h: np.ndarray = field(init=False)
    # Per-policy-joint expansions of manifest fields:
    default_pose_p: np.ndarray = field(init=False)
    action_scale_p: np.ndarray = field(init=False)
    kp_p: np.ndarray = field(init=False)
    kd_p: np.ndarray = field(init=False)
    # Hardware-order limit arrays (NaN/inf where unbounded):
    pos_lo_h: np.ndarray = field(init=False)
    pos_hi_h: np.ndarray = field(init=False)
    torque_lim_h: np.ndarray = field(init=False)
    safe_kp_h: np.ndarray = field(init=False)
    safe_kd_h: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        m, d = self.manifest, self.descriptor
        hw_index = {j.name: i for i, j in enumerate(d.joints)}

        missing = [j.name for j in m.joints if j.name not in hw_index]
        if missing:
            raise BindingError(
                f"policy '{m.name}' drives joints the robot '{d.robot}' does not "
                f"have: {missing}. Robot joints: {d.joint_names}"
            )

        self.p2h = np.array([hw_index[j.name] for j in m.joints], dtype=np.int64)
        n = m.num_joints()

        self.default_pose_p = np.asarray(m.default_pose, dtype=np.float32)
        self.action_scale_p = _expand(m.control.action_scale, n, m.joint_names)

        gains = m.control.gains
        if gains is not None:
            self.kp_p = _expand(gains.kp, n, m.joint_names)
            self.kd_p = _expand(gains.kd, n, m.joint_names)
        else:
            # Fall back to the descriptor's safe gains for the driven joints.
            self.kp_p = np.array(
                [d.joints[self.p2h[i]].safe_kp for i in range(n)], dtype=np.float32
            )
            self.kd_p = np.array(
                [d.joints[self.p2h[i]].safe_kd for i in range(n)], dtype=np.float32
            )

        nh = d.num_joints()
        self.pos_lo_h = np.full(nh, -np.inf, dtype=np.float32)
        self.pos_hi_h = np.full(nh, np.inf, dtype=np.float32)
        self.torque_lim_h = np.full(nh, np.inf, dtype=np.float32)
        self.safe_kp_h = np.array([j.safe_kp for j in d.joints], dtype=np.float32)
        self.safe_kd_h = np.array([j.safe_kd for j in d.joints], dtype=np.float32)
        for i, j in enumerate(d.joints):
            if j.pos_limit is not None:
                self.pos_lo_h[i], self.pos_hi_h[i] = j.pos_limit
            if j.torque_limit is not None:
                self.torque_lim_h[i] = j.torque_limit

        # Default pose must respect hardware limits — refuse to start otherwise.
        lo_p = self.pos_lo_h[self.p2h]
        hi_p = self.pos_hi_h[self.p2h]
        bad = (self.default_pose_p < lo_p) | (self.default_pose_p > hi_p)
        if bad.any():
            names = [m.joint_names[i] for i in np.flatnonzero(bad)]
            raise BindingError(
                f"manifest default pose violates hardware position limits for: {names}"
            )

    # -- order conversion ----------------------------------------------------

    def to_policy(self, arr_h: np.ndarray) -> np.ndarray:
        """Gather a hardware-order array into policy order."""
        return np.asarray(arr_h)[..., self.p2h]

    def to_hardware(self, arr_p: np.ndarray, fill: np.ndarray) -> np.ndarray:
        """Scatter a policy-order array into a hardware-order array.

        Joints the policy does not drive keep the values from `fill`
        (hardware order) — typically the current measured position or the
        safe damped command.
        """
        out = np.array(fill, dtype=np.float32, copy=True)
        out[self.p2h] = arr_p
        return out


def _expand(
    value: float | list[float] | dict[str, float],
    n: int,
    joint_names: list[str],
) -> np.ndarray:
    if isinstance(value, dict):
        try:
            return np.array([value[name] for name in joint_names], dtype=np.float32)
        except KeyError as e:
            raise BindingError(f"per-joint mapping missing entry for joint {e.args[0]!r}") from None
    if isinstance(value, list):
        if len(value) != n:
            raise BindingError(f"per-joint list has {len(value)} entries, expected {n}")
        return np.asarray(value, dtype=np.float32)
    return np.full(n, float(value), dtype=np.float32)
