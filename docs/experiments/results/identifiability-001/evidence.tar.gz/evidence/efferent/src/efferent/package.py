"""Policy package handling.

A deployable policy exists in one of three equivalent forms:
  1. `.app` file — a zip of manifest.yaml + policy.onnx (+ extras like obs_norm.npz)
  2. bare .onnx with an efferent manifest embedded in its metadata_props
  3. bare .onnx with a manifest.yaml sitting next to it (or passed explicitly)

`load_policy()` resolves any of these to (manifest, onnx_path, workdir).
"""

from __future__ import annotations

import tempfile
import zipfile
from pathlib import Path

import onnx
import yaml

from .spec.descriptor import RobotDescriptor
from .spec.manifest import PolicyManifest

ONNX_METADATA_KEY = "efferent.manifest"


# -- YAML loaders ------------------------------------------------------------


def load_manifest(path: str | Path) -> PolicyManifest:
    with open(path, encoding="utf-8") as f:
        return PolicyManifest.model_validate(yaml.safe_load(f))


def load_descriptor(path: str | Path) -> RobotDescriptor:
    with open(path, encoding="utf-8") as f:
        return RobotDescriptor.model_validate(yaml.safe_load(f))


# -- ONNX-embedded manifests -------------------------------------------------


def embed_manifest(
    onnx_path: str | Path, manifest: PolicyManifest, out_path: str | Path | None = None
) -> Path:
    """Write the manifest into the ONNX file's metadata_props."""
    model = onnx.load(str(onnx_path))
    props = [p for p in model.metadata_props if p.key != ONNX_METADATA_KEY]
    del model.metadata_props[:]
    model.metadata_props.extend(props)
    entry = model.metadata_props.add()
    entry.key = ONNX_METADATA_KEY
    entry.value = yaml.safe_dump(manifest.model_dump(mode="json"), sort_keys=False)
    out = Path(out_path) if out_path is not None else Path(onnx_path)
    onnx.save(model, str(out))
    return out


def extract_manifest(onnx_path: str | Path) -> PolicyManifest | None:
    model = onnx.load(str(onnx_path), load_external_data=False)
    for prop in model.metadata_props:
        if prop.key == ONNX_METADATA_KEY:
            return PolicyManifest.model_validate(yaml.safe_load(prop.value))
    return None


# -- .app archives ------------------------------------------------------------


def pack(
    manifest: PolicyManifest,
    onnx_path: str | Path,
    out_path: str | Path,
    extras: list[str | Path] | None = None,
) -> Path:
    out = Path(out_path)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(
            "manifest.yaml",
            yaml.safe_dump(manifest.model_dump(mode="json"), sort_keys=False),
        )
        z.write(onnx_path, arcname=manifest.policy.file)
        for extra in extras or []:
            z.write(extra, arcname=Path(extra).name)
    return out


def load_policy(
    path: str | Path, manifest_path: str | Path | None = None
) -> tuple[PolicyManifest, Path, Path]:
    """Resolve any supported policy form to (manifest, onnx_path, workdir)."""
    path = Path(path)
    if manifest_path is not None:
        return load_manifest(manifest_path), path, path.parent

    if path.suffix == ".app" or zipfile.is_zipfile(path):
        workdir = Path(tempfile.mkdtemp(prefix="efferent_"))
        with zipfile.ZipFile(path) as z:
            z.extractall(workdir)
        manifest = load_manifest(workdir / "manifest.yaml")
        onnx_path = workdir / manifest.policy.file
        if not onnx_path.exists():
            raise FileNotFoundError(
                f"package declares policy file '{manifest.policy.file}' but the "
                f"archive does not contain it"
            )
        return manifest, onnx_path, workdir

    if path.suffix == ".onnx":
        embedded = extract_manifest(path)
        if embedded is not None:
            return embedded, path, path.parent
        sidecar = path.with_suffix(".yaml")
        alt = path.parent / "manifest.yaml"
        for candidate in (sidecar, alt):
            if candidate.exists():
                return load_manifest(candidate), path, path.parent
        raise FileNotFoundError(
            f"{path} has no embedded efferent manifest and no sidecar "
            f"({sidecar.name} or manifest.yaml) was found next to it"
        )

    raise ValueError(f"unrecognized policy file type: {path}")
