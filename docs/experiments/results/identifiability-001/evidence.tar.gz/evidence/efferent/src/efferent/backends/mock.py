"""Mock backend: an idealized PD-driven robot for tests and dry runs.

Each joint is a unit-inertia double integrator driven by the commanded
tau = kp*(q_des - q) + kd*(dq_des - dq) + tau_ff. The base floats at
identity orientation with zero velocity.
"""

from __future__ import annotations

import numpy as np

from ..spec.descriptor import RobotDescriptor
from ..types import JointCommand, RobotState


class MockBackend:
    advances_time = True

    def __init__(self, dt: float = 0.005, substeps: int = 4, start_pose: list[float] | None = None):
        self.dt = dt
        self.substeps = substeps
        self.start_pose = start_pose
        self._t = 0.0
        self.estopped = False
        self.commands: list[JointCommand] = []

    def connect(self, descriptor: RobotDescriptor) -> None:
        self.descriptor = descriptor
        n = descriptor.num_joints()
        self.q = np.array(
            self.start_pose if self.start_pose is not None else np.zeros(n),
            dtype=np.float32,
        )
        if self.q.shape[0] != n:
            raise ValueError("start_pose length does not match descriptor joints")
        self.dq = np.zeros(n, dtype=np.float32)
        self.tau = np.zeros(n, dtype=np.float32)

    def read(self) -> RobotState:
        return RobotState(
            q=self.q.copy(),
            dq=self.dq.copy(),
            tau=self.tau.copy(),
            quat=np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32),
            gyro=np.zeros(3, dtype=np.float32),
            acc=np.array([0.0, 0.0, 9.81], dtype=np.float32),
            lin_vel=np.zeros(3, dtype=np.float32),
            stamp=self._t,
        )

    def write(self, cmd: JointCommand) -> None:
        self.commands.append(cmd)
        h = self.dt / self.substeps
        for _ in range(self.substeps):
            tau = cmd.kp * (cmd.q_des - self.q) + cmd.kd * (cmd.dq_des - self.dq) + cmd.tau_ff
            self.dq = self.dq + h * tau  # unit inertia
            self.q = self.q + h * self.dq
            self._t += h
        self.tau = tau.astype(np.float32)

    def estop(self) -> None:
        self.estopped = True

    def close(self) -> None:
        pass
