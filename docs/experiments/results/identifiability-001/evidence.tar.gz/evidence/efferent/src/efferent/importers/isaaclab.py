"""Importer: Isaac Lab / mjlab training `env.yaml` -> efferent manifest + descriptor.

Manager-based Isaac Lab (and mjlab) training runs dump their full env config
to `params/env.yaml`. That file is the source of truth for the deployment
contract — observation terms in order, action scale/offset, PD gains, effort
limits, default pose — but describes joints by REGEX. The joint ORDER lives
in the robot asset, so the caller supplies an ordered joint-name list
(a preset name from `presets.PRESETS`, or a file with one joint per line).

Notes on fidelity:
- Observation terms are mapped by name where efferent has a semantic
  equivalent; unrecognized terms become `custom.<name>` (implement them via
  a --hook module; declare `dim` to enable static checks).
- Group-level observation history (history_length > 1) is NOT translated —
  Isaac Lab stacks the whole group per timestep, which differs from
  efferent's per-term history. The importer refuses rather than silently
  producing a wrong layout.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from ..spec.descriptor import BackendRef, HwJoint, RobotDescriptor
from ..spec.manifest import (
    ControlSpec,
    GainSpec,
    JointSpec,
    ObsTerm,
    PolicyIO,
    PolicyManifest,
    Provenance,
)


class _TolerantLoader(yaml.SafeLoader):
    """Isaac Lab dumps carry python-specific tags; degrade them gracefully."""


_TolerantLoader.add_constructor(
    "tag:yaml.org,2002:python/tuple", lambda loader, node: tuple(loader.construct_sequence(node))
)


def _unknown(loader, tag_suffix, node):
    if isinstance(node, yaml.MappingNode):
        return loader.construct_mapping(node)
    if isinstance(node, yaml.SequenceNode):
        return loader.construct_sequence(node)
    return loader.construct_scalar(node)


_TolerantLoader.add_multi_constructor("tag:yaml.org,2002:python/", _unknown)


def _resolve(value, joint_names: list[str], default: float, what: str) -> list[float]:
    """Resolve a scalar / {regex: value} mapping to a per-joint list."""
    if value is None:
        return [default] * len(joint_names)
    if isinstance(value, (int, float)):
        return [float(value)] * len(joint_names)
    if isinstance(value, dict):
        out = []
        for name in joint_names:
            for pattern, v in value.items():
                if pattern == name or re.fullmatch(pattern, name):
                    out.append(float(v))
                    break
            else:
                out.append(default)
        return out
    raise ValueError(f"cannot resolve {what}: unsupported type {type(value).__name__}")


_TERM_MAP = {
    "base_ang_vel": "base_ang_vel",
    "base_lin_vel": "base_lin_vel",
    "projected_gravity": "projected_gravity",
    "projected_gravity_b": "projected_gravity",
    "joint_vel": "joint_vel",
    "joint_vel_rel": "joint_vel",
    "actions": "last_action",
    "last_action": "last_action",
    "velocity_commands": "command",
    "generated_commands": "command",
}


def import_isaaclab(
    env_yaml: str | Path,
    joint_names: list[str],
    robot_name: str = "robot",
    policy_file: str = "policy.onnx",
) -> tuple[PolicyManifest, RobotDescriptor]:
    env = yaml.load(Path(env_yaml).read_text(encoding="utf-8"), Loader=_TolerantLoader)

    # -- control rate --------------------------------------------------------
    decimation = int(env.get("decimation", 4))
    sim = env.get("sim", {})
    dt = sim.get("mujoco", {}).get("timestep") or sim.get("dt") or 0.005
    rate_hz = 1.0 / (float(dt) * decimation)

    # -- actions -------------------------------------------------------------
    actions = env.get("actions", {})
    if len(actions) != 1:
        raise ValueError(
            f"expected exactly one action term, found {list(actions)} - "
            f"multi-action-term envs are not supported yet"
        )
    a_name, a_cfg = next(iter(actions.items()))
    if "joint_pos" not in a_name:
        raise ValueError(f"unsupported action term '{a_name}' (only joint position actions)")
    action_scale = _resolve(a_cfg.get("scale"), joint_names, 1.0, "action scale")
    use_offset = bool(a_cfg.get("use_default_offset", True))
    clip = a_cfg.get("clip")
    clip_actions = None
    if isinstance(clip, dict) and clip:
        los = _resolve({k: v[0] for k, v in clip.items()}, joint_names, -1e9, "clip lo")
        his = _resolve({k: v[1] for k, v in clip.items()}, joint_names, 1e9, "clip hi")
        clip_actions = (float(min(los)), float(max(his)))

    # -- defaults & gains ----------------------------------------------------
    robot_ent = env.get("scene", {}).get("entities", {}).get("robot", {})
    init_jp = robot_ent.get("init_state", {}).get("joint_pos", {})
    defaults = _resolve(init_jp, joint_names, 0.0, "default joint pos")

    kp = [None] * len(joint_names)
    kd = [None] * len(joint_names)
    torque = [None] * len(joint_names)
    groups = robot_ent.get("articulation", {}).get("actuators", []) or []
    for g in groups:
        patterns = g.get("target_names_expr") or g.get("joint_names_expr") or ()
        for i, name in enumerate(joint_names):
            if any(p == name or re.fullmatch(p, name) for p in patterns):
                if g.get("stiffness") is not None:
                    kp[i] = _resolve(g["stiffness"], [name], 0.0, "stiffness")[0]
                if g.get("damping") is not None:
                    kd[i] = _resolve(g["damping"], [name], 0.0, "damping")[0]
                if g.get("effort_limit") is not None:
                    torque[i] = _resolve(g["effort_limit"], [name], 0.0, "effort limit")[0]
    missing = [joint_names[i] for i, v in enumerate(kp) if v is None]
    if missing:
        raise ValueError(f"no actuator group covers joints: {missing}")

    # -- observations --------------------------------------------------------
    obs_root = env.get("observations", {})
    group = obs_root.get("actor") or obs_root.get("policy")
    if group is None:
        raise ValueError(
            f"no 'actor' or 'policy' observation group found (groups: {list(obs_root)})"
        )
    hist = group.get("history_length")
    if hist and int(hist) > 1:
        raise NotImplementedError(
            f"group-level observation history (history_length={hist}) stacks "
            f"the whole group per timestep, which efferent's per-term history "
            f"does not replicate - declare the layout by hand"
        )
    terms_cfg = group.get("terms", group)
    obs_terms: list[ObsTerm] = []
    custom_terms: list[str] = []
    for key, cfg in terms_cfg.items():
        if not isinstance(cfg, dict) or ("func" not in cfg and "params" not in cfg):
            continue  # group metadata, not a term
        params = cfg.get("params") or {}
        scale = cfg.get("scale")
        scale = 1.0 if scale is None else scale
        if key == "joint_pos" or key == "joint_pos_rel":
            mapped = (
                "joint_pos_rel" if (key == "joint_pos_rel" or params.get("biased")) else "joint_pos"
            )
            obs_terms.append(ObsTerm(term=mapped, scale=scale))
        elif key in _TERM_MAP:
            kwargs: dict = {"term": _TERM_MAP[key], "scale": scale}
            if _TERM_MAP[key] == "command":
                kwargs["names"] = ["vel_x", "vel_y", "yaw_rate"]
            obs_terms.append(ObsTerm(**kwargs))
        elif key == "command" and params.get("command_name") not in (None, "base_velocity"):
            name = f"custom.{params['command_name']}_command"
            obs_terms.append(ObsTerm(term=name, scale=scale))
            custom_terms.append(name)
        elif key == "command":
            obs_terms.append(
                ObsTerm(term="command", names=["vel_x", "vel_y", "yaw_rate"], scale=scale)
            )
        else:
            name = f"custom.{key}"
            obs_terms.append(ObsTerm(term=name, scale=scale))
            custom_terms.append(name)

    manifest = PolicyManifest(
        name=f"{robot_name}-isaaclab",
        policy=PolicyIO(file=policy_file),
        control=ControlSpec(
            rate_hz=rate_hz,
            action_type="joint_position_delta" if use_offset else "joint_position",
            action_scale=action_scale,
            clip_actions=clip_actions,
            gains=GainSpec(kp=[float(v) for v in kp], kd=[float(v) for v in kd]),
        ),
        joints=[JointSpec(name=n, default=d) for n, d in zip(joint_names, defaults, strict=True)],
        observation=obs_terms,
        provenance=Provenance(
            trained_in="isaaclab/mjlab",
            notes=(
                "imported from env.yaml; custom terms need a --hook module "
                f"and a declared dim: {custom_terms}"
                if custom_terms
                else "imported from env.yaml"
            ),
        ),
    )
    descriptor = RobotDescriptor(
        robot=robot_name,
        backend=BackendRef(id="mock", params={}),
        joints=[
            HwJoint(
                name=n,
                torque_limit=float(t) if t is not None else None,
                safe_kp=float(p),
                safe_kd=float(d),
            )
            for n, t, p, d in zip(joint_names, torque, kp, kd, strict=True)
        ],
    )
    return manifest, descriptor
