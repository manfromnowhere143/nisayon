"""Unitree DDS backend (G1 / Go2 family) — hardware skeleton.

Speaks unitree_sdk2py low-level topics: subscribes LowState_, publishes
LowCmd_ with per-motor q/dq/kp/kd/tau, which is exactly the JointCommand
contract. Requires `unitree_sdk2py` (pip install unitree_sdk2py) and a robot
in debug mode (L2+R2) reachable over the configured interface.

Motor index -> joint name mapping comes from the robot descriptor: the
descriptor's joint list MUST be in SDK motor order (index 0..N-1), which is
what "hardware order" means for this backend. CRC and topic details follow
unitree_rl_gym's deploy_real implementation.

Status: validated end to end against Unitree's own DDS simulator
(unitree_mujoco's Python bridge - real unitree_sdk2py IDL, CycloneDDS,
CRC): state stream at ~460 Hz, damping and pose-tracking commands
accepted, per-joint direction check 22/22 (see scripts/modal_dds.py and
scripts/dds_sim_check.py). Physical-hardware validation pending; the
first-session procedure is examples/g1_jab/RUNBOOK.md.
"""

from __future__ import annotations

import contextlib
import time

import numpy as np

from ..spec.descriptor import RobotDescriptor
from ..types import JointCommand, RobotState


class UnitreeDdsBackend:
    advances_time = False

    def __init__(self, interface: str = "eth0", domain: int = 0, state_timeout_s: float = 0.1):
        try:
            from unitree_sdk2py.core.channel import (  # noqa: F401
                ChannelFactoryInitialize,
                ChannelPublisher,
                ChannelSubscriber,
            )
            from unitree_sdk2py.idl.default import (  # noqa: F401
                unitree_hg_msg_dds__LowCmd_,
            )
            from unitree_sdk2py.idl.unitree_hg.msg.dds_ import (  # noqa: F401
                LowCmd_,
                LowState_,
            )
            from unitree_sdk2py.utils.crc import CRC  # noqa: F401
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "Unitree backend requires unitree_sdk2py: pip install unitree_sdk2py"
            ) from e
        self._sdk = {
            "init": ChannelFactoryInitialize,
            "pub": ChannelPublisher,
            "sub": ChannelSubscriber,
            "LowCmd": LowCmd_,
            "LowState": LowState_,
            "default_cmd": unitree_hg_msg_dds__LowCmd_,
            "crc": CRC(),
        }
        self.interface = interface
        self.domain = domain
        self.state_timeout_s = state_timeout_s
        self._low_state = None
        self._state_stamp = 0.0

    # ------------------------------------------------------------------

    def connect(self, descriptor: RobotDescriptor) -> None:
        self.descriptor = descriptor
        self.n = descriptor.num_joints()
        sdk = self._sdk
        sdk["init"](self.domain, self.interface)

        self._pub = sdk["pub"]("rt/lowcmd", sdk["LowCmd"])
        self._pub.Init()
        self._sub = sdk["sub"]("rt/lowstate", sdk["LowState"])
        self._sub.Init(self._on_low_state, 10)

        deadline = time.time() + 5.0
        while self._low_state is None:
            if time.time() > deadline:
                raise TimeoutError(
                    f"no LowState received on rt/lowstate via '{self.interface}' "
                    f"within 5s — is the robot in debug mode and reachable?"
                )
            time.sleep(0.01)

    def _on_low_state(self, msg) -> None:  # DDS callback thread
        self._low_state = msg
        self._state_stamp = time.monotonic()

    # ------------------------------------------------------------------

    def read(self) -> RobotState:
        if time.monotonic() - self._state_stamp > self.state_timeout_s:
            raise TimeoutError("LowState stream stalled")
        s = self._low_state
        q = np.array([s.motor_state[i].q for i in range(self.n)], dtype=np.float32)
        dq = np.array([s.motor_state[i].dq for i in range(self.n)], dtype=np.float32)
        tau = np.array([s.motor_state[i].tau_est for i in range(self.n)], dtype=np.float32)
        quat = np.array(s.imu_state.quaternion, dtype=np.float32)  # wxyz
        gyro = np.array(s.imu_state.gyroscope, dtype=np.float32)
        acc = np.array(s.imu_state.accelerometer, dtype=np.float32)
        return RobotState(
            q=q, dq=dq, tau=tau, quat=quat, gyro=gyro, acc=acc, lin_vel=None, stamp=time.monotonic()
        )

    def write(self, cmd: JointCommand) -> None:
        sdk = self._sdk
        msg = sdk["default_cmd"]()
        msg.mode_pr = 0
        msg.mode_machine = getattr(self._low_state, "mode_machine", 0)
        for i in range(self.n):
            m = msg.motor_cmd[i]
            m.mode = 1  # enable
            m.q = float(cmd.q_des[i])
            m.dq = float(cmd.dq_des[i])
            m.kp = float(cmd.kp[i])
            m.kd = float(cmd.kd[i])
            m.tau = float(cmd.tau_ff[i])
        msg.crc = sdk["crc"].Crc(msg)
        self._pub.Write(msg)

    def estop(self) -> None:
        """Drop to pure damping using descriptor safe_kd."""
        kd = np.array([j.safe_kd for j in self.descriptor.joints], dtype=np.float32)
        with contextlib.suppress(Exception):
            self.write(JointCommand.damped(self.n, kd=kd))

    def close(self) -> None:
        pass
