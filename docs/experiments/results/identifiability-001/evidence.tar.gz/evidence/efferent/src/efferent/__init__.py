"""efferent: universal ONNX policy deployment runtime.

Any trained control policy, any robot — bound by name, never by index.
"""

__version__ = "0.5.0"

from .audit import AuditReport, audit  # noqa: F401
from .doctor import DoctorReport, doctor  # noqa: F401
from .fsm import FsmResult, FsmRunner, FsmSpec, run_fsm  # noqa: F401
from .package import (  # noqa: F401
    embed_manifest,
    extract_manifest,
    load_descriptor,
    load_manifest,
    load_policy,
    pack,
)
from .runtime.loop import Runner, RunResult, StepInfo  # noqa: F401
from .runtime.obs import register_custom_term  # noqa: F401
from .runtime.policy import PolicySession  # noqa: F401
from .simprobe import ProbeDim, SimProbeReport, run_probe  # noqa: F401
from .spec.binding import Binding, BindingError  # noqa: F401
from .spec.descriptor import BackendRef, HwJoint, RobotDescriptor  # noqa: F401
from .spec.manifest import (  # noqa: F401
    ControlSpec,
    GainSpec,
    JointSpec,
    ObsTerm,
    PolicyIO,
    PolicyManifest,
)
from .types import Command, JointCommand, RobotState  # noqa: F401
