"""The control loop: soft-start -> policy -> safety -> backend, at rate_hz.

One Runner drives one policy on one robot through one backend. Sim and real
hardware take the identical path; simulators (advances_time=True) skip
wall-clock pacing, so validation runs faster than real time.
"""

from __future__ import annotations

import contextlib
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from ..backends.base import Backend
from ..spec.binding import Binding
from ..types import Command, JointCommand, RobotState
from .obs import ObsBuilder
from .policy import PolicySession
from .safety import (
    ActionRateLimiter,
    CommandClamp,
    EnvelopeError,
    Watchdog,
    check_start_envelope,
)

logger = logging.getLogger("efferent.runner")

CommandSource = Callable[[float], Command]
StepHook = Callable[["StepInfo"], None]


@dataclass
class StepInfo:
    t: float
    state: RobotState
    obs: np.ndarray
    action: np.ndarray
    cmd: JointCommand
    phase: str


@dataclass
class RunResult:
    steps: int = 0
    duration_s: float = 0.0
    estopped: bool = False
    estop_reason: str = ""
    final_state: RobotState | None = None
    history: list[StepInfo] = field(default_factory=list)


class Runner:
    def __init__(
        self,
        binding: Binding,
        policy: PolicySession,
        backend: Backend,
        command_source: CommandSource | None = None,
        dry_run: bool = False,
        keep_history: bool = False,
        owns_backend: bool = True,
    ):
        self.b = binding
        self.policy = policy
        self.backend = backend
        self.command_source = command_source or (lambda t: Command())
        self.dry_run = dry_run
        self.keep_history = keep_history
        self.owns_backend = owns_backend  # False: caller manages connect/close/estop

        ctrl = binding.manifest.control
        self.period = 1.0 / ctrl.rate_hz
        self.obs_builder = ObsBuilder(binding)
        self.rate_limiter = ActionRateLimiter(ctrl.max_action_rate)
        self.clamp = CommandClamp(binding)
        self.watchdog = Watchdog(self.period)

    # ------------------------------------------------------------------

    def run(self, duration_s: float, soft_start: bool = True) -> RunResult:
        b = self.b
        result = RunResult()
        t0 = time.perf_counter()
        try:
            if self.owns_backend:
                self.backend.connect(b.descriptor)
            self.policy.reset()
            self.obs_builder.reset()
            self.rate_limiter.reset()
            self.watchdog.reset()

            if soft_start and not self.dry_run:
                self._soft_start()

            # Operating envelope: refuse the handoff if the robot is not in
            # a state the policy declared it can start from.
            if b.manifest.envelope is not None and not self.dry_run:
                violations = check_start_envelope(b, self.backend.read())
                if violations:
                    raise EnvelopeError(
                        "handoff refused - robot state is outside the "
                        "policy's start envelope:\n  " + "\n  ".join(violations)
                    )

            self._run_policy(duration_s, result)
        except EnvelopeError as e:
            result.estopped = True
            result.estop_reason = str(e)
            logger.error("%s", e)
            self._safe_estop()
        except _EstopSignal as e:
            result.estopped = True
            result.estop_reason = str(e)
            logger.error("ESTOP: %s", e)
            self._safe_estop()
        except Exception as e:
            result.estopped = True
            result.estop_reason = f"{type(e).__name__}: {e}"
            logger.exception("runner crashed; engaging estop")
            self._safe_estop()
            raise
        finally:
            result.duration_s = time.perf_counter() - t0
            with contextlib.suppress(Exception):
                result.final_state = self.backend.read()
            if self.owns_backend:
                self.backend.close()
        return result

    # ------------------------------------------------------------------

    def _soft_start(self) -> None:
        """Interpolate from the current pose to the policy default pose using
        the descriptor's safe gains, over startup.interp_to_default_s."""
        b = self.b
        state = self.backend.read()
        q_start = np.asarray(state.q, dtype=np.float32).copy()
        q_goal = b.to_hardware(b.default_pose_p, fill=q_start)
        steps = max(1, int(b.descriptor.startup.interp_to_default_s / self.period))
        nh = b.descriptor.num_joints()
        for i in range(steps):
            alpha = (i + 1) / steps
            cmd = JointCommand(
                q_des=(1 - alpha) * q_start + alpha * q_goal,
                dq_des=np.zeros(nh, dtype=np.float32),
                kp=b.safe_kp_h.copy(),
                kd=b.safe_kd_h.copy(),
                tau_ff=np.zeros(nh, dtype=np.float32),
            )
            state = self.backend.read()
            cmd = self.clamp(cmd, np.asarray(state.q, dtype=np.float32))
            self.backend.write(cmd)
            self._pace()

    def _run_policy(self, duration_s: float, result: RunResult) -> None:
        b = self.b
        n_steps = int(duration_s / self.period)
        last_action = np.zeros(b.manifest.num_joints(), dtype=np.float32)
        self._next_deadline = None

        for step in range(n_steps):
            now = time.perf_counter()
            if not getattr(self.backend, "advances_time", False) and self.watchdog.feed(now):
                raise _EstopSignal(
                    f"watchdog tripped: loop stalled beyond {self.watchdog.limit:.3f}s"
                )
            t = step * self.period
            state = self.backend.read()
            command = self.command_source(t)

            obs = self.obs_builder.build(state, last_action, command, t)
            action = self.policy.step(obs)
            action = self.rate_limiter(action)
            cmd = self._map_action(action, state)
            cmd = self.clamp(cmd, np.asarray(state.q, dtype=np.float32))

            if not self.dry_run:
                self.backend.write(cmd)
            last_action = action

            info = StepInfo(t=t, state=state, obs=obs, action=action, cmd=cmd, phase="running")
            if self.keep_history:
                result.history.append(info)
            result.steps += 1
            self._pace()

    def _map_action(self, action: np.ndarray, state: RobotState) -> JointCommand:
        """Interpret the raw policy output per the manifest's action_type and
        scatter it into a hardware-order command. Undriven joints hold their
        current position with safe gains."""
        b = self.b
        ctrl = b.manifest.control
        nh = b.descriptor.num_joints()
        q_now = np.asarray(state.q, dtype=np.float32)

        scaled = action * b.action_scale_p
        q_des = q_now.copy()
        dq_des = np.zeros(nh, dtype=np.float32)
        kp = b.safe_kp_h.copy()
        kd = b.safe_kd_h.copy()
        tau_ff = np.zeros(nh, dtype=np.float32)

        if ctrl.action_type == "joint_position_delta":
            q_des = b.to_hardware(b.default_pose_p + scaled, fill=q_now)
            kp = b.to_hardware(b.kp_p, fill=b.safe_kp_h)
            kd = b.to_hardware(b.kd_p, fill=b.safe_kd_h)
        elif ctrl.action_type == "joint_position":
            q_des = b.to_hardware(scaled, fill=q_now)
            kp = b.to_hardware(b.kp_p, fill=b.safe_kp_h)
            kd = b.to_hardware(b.kd_p, fill=b.safe_kd_h)
        elif ctrl.action_type == "joint_velocity":
            dq_des = b.to_hardware(scaled, fill=np.zeros(nh, dtype=np.float32))
            kp = np.zeros(nh, dtype=np.float32)
            kd = b.to_hardware(b.kd_p, fill=b.safe_kd_h)
        elif ctrl.action_type == "joint_torque":
            tau_ff = b.to_hardware(scaled, fill=np.zeros(nh, dtype=np.float32))
            kp = np.zeros(nh, dtype=np.float32)
            kd = np.zeros(nh, dtype=np.float32)
        else:  # unreachable — manifest validation restricts the literal
            raise RuntimeError(f"unhandled action_type {ctrl.action_type}")

        return JointCommand(q_des=q_des, dq_des=dq_des, kp=kp, kd=kd, tau_ff=tau_ff)

    def _safe_estop(self) -> None:
        try:
            self.backend.estop()
        except Exception:
            logger.exception("backend estop failed")

    def _pace(self) -> None:
        if getattr(self.backend, "advances_time", False):
            return
        if self._next_deadline is None:
            self._next_deadline = time.perf_counter()
        self._next_deadline += self.period
        remaining = self._next_deadline - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)
        else:
            # Overrun: rebase the deadline rather than sprinting to catch up.
            self._next_deadline = time.perf_counter()

    _next_deadline: float | None = None


class _EstopSignal(RuntimeError):
    pass
