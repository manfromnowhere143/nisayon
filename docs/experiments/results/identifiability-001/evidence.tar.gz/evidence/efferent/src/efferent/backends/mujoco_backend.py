"""MuJoCo backend: makes any MJCF model a deployment target.

Torques are applied directly to joint DOFs (qfrc_applied), so models need no
actuator definitions. PD is evaluated at the physics timestep, mirroring how
motor controllers run PD faster than the policy rate on real hardware.

The same runtime that drives real robots drives this backend — which is the
point: sim-to-sim validation is `--backend mujoco` instead of a rewrite.
"""

from __future__ import annotations

import numpy as np

from ..runtime.obs import quat_rotate_inverse
from ..spec.descriptor import RobotDescriptor
from ..types import JointCommand, RobotState


class MujocoBackend:
    advances_time = True

    def __init__(
        self,
        model_xml: str,
        control_dt: float = 0.02,
        render: bool = False,
        start_pose: dict[str, float] | None = None,
        base_pos: list[float] | None = None,  # [x, y, z] for floating base
        base_quat: list[float] | None = None,  # wxyz
        auto_base_height: bool = False,  # drop base so lowest geom touches z=0
        settle_s: float = 0.0,  # PD-hold start_pose this long before handover
    ):
        try:
            import mujoco
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "MuJoCo backend requires the 'mujoco' package: pip install efferent[mujoco]"
            ) from e
        self._mj = mujoco
        self.model = mujoco.MjModel.from_xml_path(model_xml)
        self.data = mujoco.MjData(self.model)
        self.control_dt = control_dt
        self.substeps = max(1, round(control_dt / self.model.opt.timestep))
        self.render = render
        self.start_pose = start_pose or {}
        self.base_pos = base_pos
        self.base_quat = base_quat
        self.auto_base_height = auto_base_height
        self.settle_s = settle_s
        self._viewer = None
        self.estopped = False

    def connect(self, descriptor: RobotDescriptor) -> None:
        mujoco = self._mj
        self.descriptor = descriptor
        self.qpos_adr: list[int] = []
        self.dof_adr: list[int] = []
        model_joints = [
            mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, j)
            for j in range(self.model.njnt)
        ]
        for hw_joint in descriptor.joints:
            jid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, hw_joint.name)
            if jid < 0:
                raise ValueError(
                    f"descriptor joint '{hw_joint.name}' not found in MJCF. "
                    f"Model joints: {model_joints}"
                )
            jtype = self.model.jnt_type[jid]
            if jtype not in (mujoco.mjtJoint.mjJNT_HINGE, mujoco.mjtJoint.mjJNT_SLIDE):
                raise ValueError(f"joint '{hw_joint.name}' is not a hinge/slide joint")
            self.qpos_adr.append(int(self.model.jnt_qposadr[jid]))
            self.dof_adr.append(int(self.model.jnt_dofadr[jid]))

        # Optional floating base: first free joint found, if any.
        self._free_qpos_adr: int | None = None
        self._free_dof_adr: int | None = None
        for j in range(self.model.njnt):
            if self.model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE:
                self._free_qpos_adr = int(self.model.jnt_qposadr[j])
                self._free_dof_adr = int(self.model.jnt_dofadr[j])
                break

        mujoco.mj_resetData(self.model, self.data)
        if self._free_qpos_adr is not None:
            qa = self._free_qpos_adr
            if self.base_pos is not None:
                self.data.qpos[qa : qa + 3] = self.base_pos
            if self.base_quat is not None:
                self.data.qpos[qa + 3 : qa + 7] = self.base_quat
        for name, value in self.start_pose.items():
            jid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
            if jid < 0:
                raise ValueError(f"start_pose joint '{name}' not found in MJCF")
            self.data.qpos[self.model.jnt_qposadr[jid]] = value
        mujoco.mj_forward(self.model, self.data)

        if self.auto_base_height and self._free_qpos_adr is not None:
            # Lower/raise the base so the robot's lowest collision geometry
            # sits just above the ground plane, then let contacts settle —
            # a bad spawn height topples a robot before any policy runs.
            zmin = np.inf
            for g in range(self.model.ngeom):
                if self.model.geom_bodyid[g] == 0:  # world (floor) geoms
                    continue
                zmin = min(zmin, self.data.geom_xpos[g][2] - self.model.geom_rbound[g])
            if np.isfinite(zmin):
                self.data.qpos[self._free_qpos_adr + 2] += 0.005 - zmin
                mujoco.mj_forward(self.model, self.data)

        if self.settle_s > 0.0:
            q_hold = np.array([self.data.qpos[a] for a in self.qpos_adr], dtype=np.float32)
            hold = JointCommand(
                q_des=q_hold,
                dq_des=np.zeros(len(self.dof_adr), dtype=np.float32),
                kp=np.array([j.safe_kp for j in descriptor.joints], dtype=np.float32),
                kd=np.array([j.safe_kd for j in descriptor.joints], dtype=np.float32),
                tau_ff=np.zeros(len(self.dof_adr), dtype=np.float32),
            )
            for _ in range(int(self.settle_s / self.control_dt)):
                self.write(hold)

        if self.render:  # pragma: no cover - interactive only
            import mujoco.viewer

            self._viewer = mujoco.viewer.launch_passive(self.model, self.data)

    # ------------------------------------------------------------------

    def read(self) -> RobotState:
        q = np.array([self.data.qpos[a] for a in self.qpos_adr], dtype=np.float32)
        dq = np.array([self.data.qvel[a] for a in self.dof_adr], dtype=np.float32)
        quat = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)
        gyro = np.zeros(3, dtype=np.float32)
        lin_vel = np.zeros(3, dtype=np.float32)
        if self._free_qpos_adr is not None and self._free_dof_adr is not None:
            qa, da = self._free_qpos_adr, self._free_dof_adr
            quat = self.data.qpos[qa + 3 : qa + 7].astype(np.float32)  # wxyz
            # Free joint qvel: linear (world frame), angular (body frame).
            gyro = self.data.qvel[da + 3 : da + 6].astype(np.float32)
            lin_vel = quat_rotate_inverse(
                quat.astype(np.float64), self.data.qvel[da : da + 3].astype(np.float64)
            )
        return RobotState(
            q=q,
            dq=dq,
            tau=None,
            quat=quat,
            gyro=gyro,
            acc=None,
            lin_vel=lin_vel,
            stamp=float(self.data.time),
        )

    def write(self, cmd: JointCommand) -> None:
        for _ in range(self.substeps):
            q = np.array([self.data.qpos[a] for a in self.qpos_adr])
            dq = np.array([self.data.qvel[a] for a in self.dof_adr])
            tau = cmd.kp * (cmd.q_des - q) + cmd.kd * (cmd.dq_des - dq) + cmd.tau_ff
            self.data.qfrc_applied[:] = 0.0
            for a, t in zip(self.dof_adr, tau, strict=True):
                self.data.qfrc_applied[a] = t
            self._mj.mj_step(self.model, self.data)
        if self._viewer is not None:  # pragma: no cover
            self._viewer.sync()

    def estop(self) -> None:
        """Simulate 1s of pure damping, mirroring real damped-mode behavior."""
        self.estopped = True
        nh = len(self.dof_adr)
        cmd = JointCommand.damped(nh, kd=np.array([j.safe_kd for j in self.descriptor.joints]))
        for _ in range(int(1.0 / self.control_dt)):
            self.write(cmd)

    def close(self) -> None:
        if self._viewer is not None:  # pragma: no cover
            self._viewer.close()
            self._viewer = None
