"""Observation builder: assembles the flat obs vector a policy expects from
semantic terms, using the manifest as the recipe.

History convention: a term with history=N contributes N copies stacked
newest-first — [x_t, x_{t-1}, ..., x_{t-N+1}] — matching the "index 0 is the
latest" convention used by rl_sar and most deploy stacks.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Callable

import numpy as np

from ..spec.binding import Binding
from ..spec.manifest import ObsTerm
from ..types import Command, RobotState

# Custom term hook: fn(binding, state, ctx) -> 1-D float32 array.
CustomTermFn = Callable[[Binding, RobotState, dict], np.ndarray]
_CUSTOM_TERMS: dict[str, CustomTermFn] = {}


def register_custom_term(name: str, fn: CustomTermFn) -> None:
    if not name.startswith("custom."):
        raise ValueError("custom term names must start with 'custom.'")
    _CUSTOM_TERMS[name] = fn


def quat_rotate_inverse(quat_wxyz: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Rotate world-frame vector v into the body frame given body quat (wxyz)."""
    w, x, y, z = quat_wxyz
    q_vec = np.array([x, y, z], dtype=np.float64)
    a = v * (2.0 * w * w - 1.0)
    b = 2.0 * w * np.cross(q_vec, v)
    c = 2.0 * q_vec * np.dot(q_vec, v)
    return (a - b + c).astype(np.float32)


class ObsBuilder:
    def __init__(self, binding: Binding):
        self.binding = binding
        self.terms = binding.manifest.observation
        self._history: list[deque[np.ndarray]] = [deque(maxlen=t.history) for t in self.terms]
        self._dims: list[int | None] = [None] * len(self.terms)

    def reset(self) -> None:
        for h in self._history:
            h.clear()

    def build(
        self,
        state: RobotState,
        last_action: np.ndarray,
        command: Command,
        t: float,
        ctx: dict | None = None,
    ) -> np.ndarray:
        parts: list[np.ndarray] = []
        base_ctx = {"t": t, "command": command, "last_action": last_action}
        if ctx:
            base_ctx.update(ctx)
        for i, term in enumerate(self.terms):
            raw = self._produce(term, state, last_action, command, t, base_ctx)
            raw = np.asarray(raw, dtype=np.float32).ravel()
            if self._dims[i] is None:
                if term.dim is not None and raw.shape[0] != term.dim:
                    raise RuntimeError(
                        f"term '{term.term}' declares dim={term.dim} in the "
                        f"manifest but produced {raw.shape[0]} values"
                    )
                self._dims[i] = raw.shape[0]
            elif raw.shape[0] != self._dims[i]:
                raise RuntimeError(
                    f"term '{term.term}' changed dimension mid-run: "
                    f"{self._dims[i]} -> {raw.shape[0]}"
                )
            scaled = raw * self._scale(term, raw.shape[0])
            hist = self._history[i]
            hist.appendleft(scaled)
            while len(hist) < term.history:  # pad startup with oldest copy
                hist.append(scaled)
            parts.append(np.concatenate(list(hist)) if term.history > 1 else scaled)
        return np.concatenate(parts)

    def dim(self) -> int | None:
        """Total obs dimension, known after the first build() call."""
        if any(d is None for d in self._dims):
            return None
        return int(
            sum(d * t.history for d, t in zip(self._dims, self.terms, strict=True))  # type: ignore[operator]
        )

    # ------------------------------------------------------------------

    def _scale(self, term: ObsTerm, dim: int) -> np.ndarray:
        if isinstance(term.scale, list):
            if len(term.scale) != dim:
                raise RuntimeError(
                    f"term '{term.term}' scale list has {len(term.scale)} entries "
                    f"but the term produces {dim} values"
                )
            return np.asarray(term.scale, dtype=np.float32)
        return np.float32(term.scale)

    def _produce(
        self,
        term: ObsTerm,
        state: RobotState,
        last_action: np.ndarray,
        command: Command,
        t: float,
        ctx: dict,
    ) -> np.ndarray:
        b = self.binding
        name = term.term
        if name == "base_lin_vel":
            return _required(state.lin_vel, name)
        if name == "base_ang_vel":
            return _required(state.gyro, name)
        if name == "projected_gravity":
            quat = _required(state.quat, name)
            return quat_rotate_inverse(quat, np.array([0.0, 0.0, -1.0]))
        if name == "base_quat":
            return _required(state.quat, name)
        if name == "joint_pos":
            return b.to_policy(state.q)
        if name == "joint_pos_rel":
            return b.to_policy(state.q) - b.default_pose_p
        if name == "joint_vel":
            return b.to_policy(state.dq)
        if name == "joint_torque":
            return b.to_policy(_required(state.tau, name))
        if name == "last_action":
            return last_action
        if name == "command":
            vec = command.vector()
            if term.names is not None and len(term.names) != vec.shape[0]:
                raise RuntimeError(
                    f"manifest command term names {term.names} do not match the "
                    f"runtime command dims {command.names}"
                )
            return vec
        if name == "time":
            return np.array([t], dtype=np.float32)
        if name == "phase":
            freq = float(term.params.get("freq", 1.0))
            ph = 2.0 * np.pi * freq * t
            return np.array([np.sin(ph), np.cos(ph)], dtype=np.float32)
        if name.startswith("custom."):
            fn = _CUSTOM_TERMS.get(name)
            if fn is None:
                raise RuntimeError(
                    f"custom term '{name}' is not registered "
                    f"(call efferent.register_custom_term first)"
                )
            return fn(b, state, {**term.params, **ctx})
        raise RuntimeError(f"unhandled observation term '{name}'")


def _required(value: np.ndarray | None, term: str) -> np.ndarray:
    if value is None:
        raise RuntimeError(
            f"observation term '{term}' needs a sensor signal the backend did not provide"
        )
    return np.asarray(value, dtype=np.float32)
