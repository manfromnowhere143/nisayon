"""Shared runtime data types. All joint-indexed arrays are in HARDWARE order."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class RobotState:
    """One sensor snapshot from a backend."""

    q: np.ndarray  # joint positions [nh]
    dq: np.ndarray  # joint velocities [nh]
    tau: np.ndarray | None = None  # measured joint torques [nh]
    quat: np.ndarray | None = None  # base orientation, wxyz, world frame
    gyro: np.ndarray | None = None  # base angular velocity, base frame [3]
    acc: np.ndarray | None = None  # base linear acceleration, base frame [3]
    lin_vel: np.ndarray | None = None  # base linear velocity, base frame [3]
    stamp: float = 0.0  # backend-provided monotonic time (s)


@dataclass
class JointCommand:
    """One actuation command to a backend: tau = kp*(q_des-q) + kd*(dq_des-dq) + tau_ff."""

    q_des: np.ndarray
    dq_des: np.ndarray
    kp: np.ndarray
    kd: np.ndarray
    tau_ff: np.ndarray

    @classmethod
    def damped(cls, nh: int, kd: np.ndarray | float = 2.0) -> JointCommand:
        """Pure damping — the universal safe fallback."""
        z = np.zeros(nh, dtype=np.float32)
        kd_arr = (
            np.full(nh, kd, dtype=np.float32)
            if np.isscalar(kd)
            else np.asarray(kd, dtype=np.float32)
        )
        return cls(q_des=z.copy(), dq_des=z.copy(), kp=z.copy(), kd=kd_arr, tau_ff=z.copy())


@dataclass
class Command:
    """Task command fed to the policy (e.g. velocity target). Named dims."""

    names: list[str] = field(default_factory=lambda: ["vel_x", "vel_y", "yaw_rate"])
    values: np.ndarray | None = None

    def __post_init__(self) -> None:
        if self.values is None:
            self.values = np.zeros(len(self.names), dtype=np.float32)

    def vector(self) -> np.ndarray:
        return np.asarray(self.values, dtype=np.float32)
