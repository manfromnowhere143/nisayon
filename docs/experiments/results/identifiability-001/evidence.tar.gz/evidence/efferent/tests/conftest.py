from __future__ import annotations

from pathlib import Path

import numpy as np
import onnx
import pytest
from onnx import TensorProto, helper

from efferent import (
    BackendRef,
    ControlSpec,
    GainSpec,
    HwJoint,
    JointSpec,
    ObsTerm,
    PolicyIO,
    PolicyManifest,
    RobotDescriptor,
)


def make_linear_policy(
    path: Path,
    obs_dim: int,
    act_dim: int,
    W: np.ndarray | None = None,
    b: np.ndarray | None = None,
    state_dim: int | None = None,
) -> Path:
    """Build a minimal ONNX policy: actions = W @ obs + b, optional identity
    recurrent state passthrough (h_out = h_in)."""
    W = np.zeros((act_dim, obs_dim), dtype=np.float32) if W is None else W.astype(np.float32)
    b = np.zeros(act_dim, dtype=np.float32) if b is None else b.astype(np.float32)

    obs_in = helper.make_tensor_value_info("obs", TensorProto.FLOAT, [1, obs_dim])
    act_out = helper.make_tensor_value_info("actions", TensorProto.FLOAT, [1, act_dim])
    nodes = [
        helper.make_node("Gemm", ["obs", "W", "b"], ["actions"], transB=1),
    ]
    inputs, outputs = [obs_in], [act_out]
    inits = [
        helper.make_tensor("W", TensorProto.FLOAT, W.shape, W.flatten()),
        helper.make_tensor("b", TensorProto.FLOAT, b.shape, b),
    ]
    if state_dim is not None:
        inputs.append(helper.make_tensor_value_info("h_in", TensorProto.FLOAT, [state_dim]))
        outputs.append(helper.make_tensor_value_info("h_out", TensorProto.FLOAT, [state_dim]))
        nodes.append(helper.make_node("Identity", ["h_in"], ["h_out"]))

    graph = helper.make_graph(nodes, "policy", inputs, outputs, inits)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 9
    onnx.checker.check_model(model)
    onnx.save(model, str(path))
    return path


def biped_manifest(**overrides) -> PolicyManifest:
    """A 4-joint test policy manifest (policy joint order)."""
    defaults = dict(
        name="test-policy",
        policy=PolicyIO(file="policy.onnx"),
        control=ControlSpec(
            rate_hz=50.0,
            action_type="joint_position_delta",
            action_scale=0.25,
            gains=GainSpec(kp=30.0, kd=8.0),
        ),
        joints=[
            JointSpec(name="left_hip", default=0.1),
            JointSpec(name="left_knee", default=0.3),
            JointSpec(name="right_hip", default=-0.1),
            JointSpec(name="right_knee", default=0.3),
        ],
        observation=[
            ObsTerm(term="joint_pos_rel"),
            ObsTerm(term="joint_vel", scale=0.05),
            ObsTerm(term="last_action"),
        ],
    )
    defaults.update(overrides)
    return PolicyManifest(**defaults)


def biped_descriptor(**overrides) -> RobotDescriptor:
    """Hardware order deliberately differs from policy order."""
    defaults = dict(
        robot="testbot",
        backend=BackendRef(id="mock", params={}),
        joints=[
            HwJoint(name="right_knee", torque_limit=40.0, pos_limit=(-1.5, 1.5)),
            HwJoint(name="left_hip", torque_limit=40.0, pos_limit=(-1.5, 1.5)),
            HwJoint(name="torso_pitch", torque_limit=40.0, pos_limit=(-1.0, 1.0)),
            HwJoint(name="right_hip", torque_limit=40.0, pos_limit=(-1.5, 1.5)),
            HwJoint(name="left_knee", torque_limit=40.0, pos_limit=(-1.5, 1.5)),
        ],
    )
    defaults.update(overrides)
    return RobotDescriptor(**defaults)


@pytest.fixture
def fixtures_dir() -> Path:
    return Path(__file__).parent / "fixtures"
