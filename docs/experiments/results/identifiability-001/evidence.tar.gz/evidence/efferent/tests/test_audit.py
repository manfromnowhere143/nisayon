"""The audit must catch the obs-builder bug classes documented in real
deployment issue trackers — each planted here exactly as reported:
world-frame velocity (rl_sar #88/#183), missing scale factors, and permuted
joint columns."""

import numpy as np
import pytest
import yaml

from efferent import Binding, Command, RobotState, audit
from efferent.runtime.obs import ObsBuilder, quat_rotate_inverse
from efferent.spec.manifest import ObsTerm

from .conftest import biped_descriptor, biped_manifest

T, N = 40, 4


def _manifest():
    return biped_manifest(
        observation=[
            ObsTerm(term="base_ang_vel", scale=0.25),
            ObsTerm(term="projected_gravity"),
            ObsTerm(term="joint_pos_rel"),
            ObsTerm(term="joint_vel", scale=0.05),
            ObsTerm(term="last_action"),
        ]
    )


def _random_quat(rng):
    q = rng.normal(0, 1, 4)
    q /= np.linalg.norm(q)
    return q if q[0] >= 0 else -q


def _make_log(tmp_path, manifest, corrupt=None):
    """Generate a synthetic deploy log: raw states + the obs a CORRECT
    pipeline builds, then optionally corrupt one term the way real deploy
    stacks get it wrong. Returns (log_path, manifest_path)."""
    rng = np.random.default_rng(0)
    descriptor = biped_descriptor()
    binding = Binding(manifest, descriptor)
    builder = ObsBuilder(binding)
    nh = descriptor.num_joints()

    q = rng.normal(0, 0.3, (T, nh)).astype(np.float32)
    dq = rng.normal(0, 1.0, (T, nh)).astype(np.float32)
    quat = np.stack([_random_quat(rng) for _ in range(T)]).astype(np.float32)
    gyro = rng.normal(0, 1.0, (T, 3)).astype(np.float32)
    action = rng.normal(0, 0.5, (T, N)).astype(np.float32)

    obs = []
    for t in range(T):
        state = RobotState(q=q[t], dq=dq[t], quat=quat[t], gyro=gyro[t])
        last = action[t - 1] if t > 0 else np.zeros(N, np.float32)
        obs.append(builder.build(state, last, Command(), t * 0.02))
    obs = np.stack(obs)

    if corrupt == "world_frame_ang_vel":
        # pipeline forgot quat_rotate_inverse: logged ang_vel is world frame
        for t in range(T):
            w, x, y, z = quat[t]
            conj = np.array([w, -x, -y, -z])
            obs[t, 0:3] = 0.25 * quat_rotate_inverse(conj, gyro[t].astype(np.float64))
    elif corrupt == "missing_scale":
        obs[:, 10:14] /= 0.05  # joint_vel logged unscaled
    elif corrupt == "permuted_jpos":
        obs[:, 6:10] = obs[:, [7, 6, 9, 8]]  # jpos columns swapped in pairs

    log_path = tmp_path / "log.npz"
    np.savez(log_path, obs=obs, q=q, dq=dq, quat=quat, gyro=gyro, action=action)
    manifest_path = tmp_path / "manifest.yaml"
    manifest_path.write_text(yaml.safe_dump(manifest.model_dump(mode="json")), encoding="utf-8")
    robot_path = tmp_path / "robot.yaml"
    robot_path.write_text(yaml.safe_dump(descriptor.model_dump(mode="json")), encoding="utf-8")
    return log_path, manifest_path, robot_path


def _term(report, name):
    return next(t for t in report.terms if t.term == name)


class TestAudit:
    def test_correct_pipeline_passes_every_term(self, tmp_path):
        log, mf, robot = _make_log(tmp_path, _manifest())
        report = audit(mf, log=log, robot=robot)
        assert report.passed, str(report)
        assert all(t.status == "PASS" for t in report.terms)

    def test_world_frame_ang_vel_diagnosed(self, tmp_path):
        """rl_sar #88/#183: velocity fed in world frame instead of body."""
        log, mf, robot = _make_log(tmp_path, _manifest(), corrupt="world_frame_ang_vel")
        report = audit(mf, log=log, robot=robot)
        t = _term(report, "base_ang_vel")
        assert t.status == "FAIL", str(report)
        assert "WORLD-frame" in t.hint and "BODY frame" in t.hint
        # only the guilty term fails
        assert _term(report, "joint_pos_rel").status == "PASS"

    def test_missing_scale_diagnosed_with_factor(self, tmp_path):
        log, mf, robot = _make_log(tmp_path, _manifest(), corrupt="missing_scale")
        report = audit(mf, log=log, robot=robot)
        t = _term(report, "joint_vel")
        assert t.status == "FAIL"
        assert "scale mismatch" in t.hint and "20" in t.hint

    def test_permuted_joint_columns_diagnosed_with_mapping(self, tmp_path):
        log, mf, robot = _make_log(tmp_path, _manifest(), corrupt="permuted_jpos")
        report = audit(mf, log=log, robot=robot)
        t = _term(report, "joint_pos_rel")
        assert t.status == "FAIL"
        assert "PERMUTATION" in t.hint
        assert "[1, 0, 3, 2]" in t.hint

    def test_missing_required_key_is_clear(self, tmp_path):
        log, mf, robot = _make_log(tmp_path, _manifest())
        data = dict(np.load(log))
        del data["q"]
        np.savez(log, **data)
        with pytest.raises(ValueError, match="missing required array 'q'"):
            audit(mf, log=log, robot=robot)

    def test_wrong_manifest_dim_is_clear(self, tmp_path):
        log, _, robot = _make_log(tmp_path, _manifest())
        small = biped_manifest()  # 12-dim recipe vs 18-dim log
        mf2 = tmp_path / "wrong.yaml"
        mf2.write_text(yaml.safe_dump(small.model_dump(mode="json")), encoding="utf-8")
        with pytest.raises(ValueError, match="wrong manifest"):
            audit(mf2, log=log, robot=robot)
