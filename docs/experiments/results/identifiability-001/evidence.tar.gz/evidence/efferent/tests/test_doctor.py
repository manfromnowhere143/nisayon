"""The doctor must catch the bug classes that fill deployment issue trackers:
permuted joint order, dead command wiring, numeric blowups, and pipeline
drift vs a training-side recording — each planted deliberately here."""

import numpy as np
import yaml

from efferent import doctor
from efferent.spec.manifest import ObsTerm

from .conftest import biped_descriptor, biped_manifest, make_linear_policy

N = 4  # joints
OBS = 12  # joint_pos_rel(4) + joint_vel(4) + last_action(4)


def _healthy_W() -> np.ndarray:
    """action_j responds to joint_pos_rel_j (diagonal), with light coupling to
    the other blocks so no term is dead."""
    W = np.zeros((N, OBS), dtype=np.float32)
    W[:, 0:N] = -1.0 * np.eye(N)  # joint_pos_rel: diagonal response
    W[:, N : 2 * N] = -0.05 * np.eye(N)  # joint_vel: damping-ish
    W[:, 2 * N : 3 * N] = 0.1 * np.eye(N)  # last_action: smoothing-ish
    return W


def _setup(tmp_path, W, manifest=None, robot=None):
    m = manifest or biped_manifest()
    onnx_path = make_linear_policy(
        tmp_path / "policy.onnx", OBS if W is None else W.shape[1], N, W=W
    )
    (tmp_path / "manifest.yaml").write_text(
        yaml.safe_dump(m.model_dump(mode="json")), encoding="utf-8"
    )
    robot_path = None
    if robot is not None:
        robot_path = tmp_path / "robot.yaml"
        robot_path.write_text(yaml.safe_dump(robot.model_dump(mode="json")), encoding="utf-8")
    return onnx_path, robot_path


def _check(report, name):
    return next(c for c in report.checks if c.name.startswith(name))


class TestDoctorCatchesPlantedBugs:
    def test_healthy_policy_passes(self, tmp_path):
        onnx_path, robot_path = _setup(tmp_path, _healthy_W(), robot=biped_descriptor())
        report = doctor(onnx_path, robot=robot_path)
        assert report.passed, str(report)
        assert _check(report, "joint-order fingerprint").status == "PASS"
        assert _check(report, "no dead observation terms").status == "PASS"
        assert _check(report, "binds to robot").status == "PASS"

    def test_permuted_joint_order_detected_with_mapping(self, tmp_path):
        """THE classic silent bug: obs joint block wired in a different order
        than the action order. Doctor must fail and name the permutation."""
        perm = [1, 0, 3, 2]
        W = _healthy_W()
        W[:, 0:N] = 0.0
        for j, i in enumerate(perm):  # action j responds to obs joint dim i
            W[j, i] = -1.0
        onnx_path, _ = _setup(tmp_path, W)
        report = doctor(onnx_path)
        c = _check(report, "joint-order fingerprint")
        assert c.status == "FAIL", str(report)
        assert "PERMUTED" in c.detail
        assert str(perm) in c.detail  # observed obs->action mapping printed

    def test_dead_command_block_flagged(self, tmp_path):
        """Robot-ignores-the-joystick bug: command dims wired to nothing."""
        m = biped_manifest(
            observation=[
                ObsTerm(term="command", names=["vx", "vy", "wz"]),
                ObsTerm(term="joint_pos_rel"),
                ObsTerm(term="joint_vel"),
                ObsTerm(term="last_action"),
            ]
        )
        W = np.zeros((N, 3 + OBS), dtype=np.float32)
        W[:, 3 : 3 + N] = -1.0 * np.eye(N)  # joints wired, command dead
        W[:, 3 + N : 3 + 2 * N] = -0.05 * np.eye(N)
        W[:, 3 + 2 * N :] = 0.1 * np.eye(N)
        onnx_path, _ = _setup(tmp_path, W, manifest=m)
        report = doctor(onnx_path)
        c = _check(report, "no dead observation terms")
        assert c.status == "WARN"
        assert "command" in c.detail

    def test_numeric_blowup_fails(self, tmp_path):
        W = _healthy_W() * np.float32(1e38)  # overflows to inf on large inputs
        onnx_path, _ = _setup(tmp_path, W)
        report = doctor(onnx_path)
        assert not report.passed
        assert _check(report, "numeric robustness").status == "FAIL"

    def test_wrong_obs_recipe_fails(self, tmp_path):
        m = biped_manifest(
            observation=[ObsTerm(term="joint_pos_rel"), ObsTerm(term="joint_vel")]
        )  # recipe -> 8 dims, network expects 12
        onnx_path, _ = _setup(tmp_path, _healthy_W(), manifest=m)
        report = doctor(onnx_path)
        c = _check(report, "obs recipe size vs network input")
        assert c.status == "FAIL"
        assert "8" in c.detail and "12" in c.detail

    def test_binding_failure_reported_not_raised(self, tmp_path):
        from efferent import HwJoint

        bad_robot = biped_descriptor(
            joints=[HwJoint(name="left_hip"), HwJoint(name="mystery_joint")]
        )
        onnx_path, robot_path = _setup(tmp_path, _healthy_W(), robot=bad_robot)
        report = doctor(onnx_path, robot=robot_path)
        c = _check(report, "binds to robot")
        assert c.status == "FAIL"
        assert not report.passed


class TestReplayCheck:
    def test_faithful_pipeline_passes(self, tmp_path):
        onnx_path, _ = _setup(tmp_path, _healthy_W())
        from efferent import PolicySession, load_policy

        m, p, wd = load_policy(onnx_path)
        sess = PolicySession(m, p, norm_dir=wd)
        rng = np.random.default_rng(1)
        obs = rng.normal(0, 0.3, (20, OBS)).astype(np.float32)
        actions = np.stack([sess.step(o) for o in obs])
        np.savez(tmp_path / "ref.npz", obs=obs, actions=actions)
        report = doctor(onnx_path, reference=tmp_path / "ref.npz")
        assert _check(report, "reference replay").status == "PASS"

    def test_divergent_pipeline_fails(self, tmp_path):
        onnx_path, _ = _setup(tmp_path, _healthy_W())
        rng = np.random.default_rng(1)
        obs = rng.normal(0, 0.3, (20, OBS)).astype(np.float32)
        wrong_actions = rng.normal(0, 1, (20, N)).astype(np.float32)
        np.savez(tmp_path / "ref.npz", obs=obs, actions=wrong_actions)
        report = doctor(onnx_path, reference=tmp_path / "ref.npz")
        c = _check(report, "reference replay")
        assert c.status == "FAIL"
        assert "diverges" in c.detail


class TestCustomTermDims:
    def test_declared_dims_enable_static_checks(self, tmp_path):
        m = biped_manifest(
            observation=[
                ObsTerm(term="custom.motion", dim=6),
                ObsTerm(term="joint_pos_rel"),
                ObsTerm(term="joint_vel"),
                ObsTerm(term="last_action"),
            ]
        )
        W = np.zeros((N, 6 + OBS), dtype=np.float32)
        W[:, 0:6] = 0.2
        W[:, 6 : 6 + N] = -1.0 * np.eye(N)
        W[:, 6 + N : 6 + 2 * N] = -0.05 * np.eye(N)
        W[:, 6 + 2 * N :] = 0.1 * np.eye(N)
        onnx_path, _ = _setup(tmp_path, W, manifest=m)
        report = doctor(onnx_path)
        assert _check(report, "obs recipe size vs network input").status == "PASS"
        assert _check(report, "joint-order fingerprint").status == "PASS"
