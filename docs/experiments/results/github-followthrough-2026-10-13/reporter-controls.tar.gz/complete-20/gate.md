## Arisole Robot Reliability Gate (`REVIEW`)

- Suite: `arisole-eval-lerobot-v0.1` v`0.1.4`
- Gate engine: `deployment-gate-v1`
- Config: `arisole-reliability-ci-v1`
- Suite status: `partial`

### Reasons
- **PASS** · `pass_to_fail_rate` — pass_to_fail_rate=0.000 over 20 labelled paired episodes
- **REVIEW** · `min_episodes_for_strong_claim` — pass_to_fail_rate is low but labelled_paired_episodes=20 < min_episodes_for_strong_claim=30
- **REVIEW** · `trajectory_deviation` — Trajectory deviation unavailable (coordinate channels missing); noted, not fabricated.

### Transitions
- Matched (shared seeds): 20
- Comparable (fully labelled): 20
- Incomparable / unknown labels: 0
- P2F: 0 · F2P: 0 · F2F: 0 · P2P: 20

### Honesty
- Missing success labels or weak n never become PASS.
- Regression rates use labelled pairs only; INCOMPARABLE rows stay unknown.
- Trajectory metrics remain `insufficient_data` when channels are absent.
- Secrets must never appear in this summary.

### Reproducibility
```json
{
  "suite_id": "arisole-eval-lerobot-v0.1",
  "suite_version": "0.1.4",
  "gate_engine_version": "deployment-gate-v1",
  "config_version": "arisole-reliability-ci-v1",
  "evaluator_pinned": true,
  "artifact_hashes": {
    "baseline": {},
    "candidate": {}
  }
}
```
