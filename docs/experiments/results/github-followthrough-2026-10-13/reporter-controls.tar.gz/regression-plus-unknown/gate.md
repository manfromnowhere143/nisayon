## Arisole Robot Reliability Gate (`INSUFFICIENT_DATA`)

- Suite: `arisole-eval-lerobot-v0.1` v`0.1.4`
- Gate engine: `deployment-gate-v1`
- Config: `arisole-reliability-ci-v1`
- Suite status: `partial`

### Reasons
- **INSUFFICIENT_DATA** · `require_paired_success_labels` — 30 of 60 seed-matched pairs lack an observed outcome; retain them as unknown, not as observed non-regressions.
- **REVIEW** · `pass_to_fail_rate` — pass_to_fail_rate=0.200 between promote (0.05) and block (0.25) thresholds
- **REVIEW** · `trajectory_deviation` — Trajectory deviation unavailable (coordinate channels missing); noted, not fabricated.

### Transitions
- Matched (shared seeds): 60
- Comparable (fully labelled): 30
- Incomparable / unknown labels: 30
- P2F: 6 · F2P: 0 · F2F: 0 · P2P: 24

### Honesty
- Missing success labels or weak n never become PASS.
- Regression rates use labelled pairs only; INCOMPARABLE rows stay unknown.
- Trajectory metrics remain `insufficient_data` when channels are absent.
- Secrets must never appear in this summary.

### Reproducibility
```json
{
  "suite_id": "arisole-eval-lerobot-v0.1",
  "suite_version": "0.1.4",
  "gate_engine_version": "deployment-gate-v1",
  "config_version": "arisole-reliability-ci-v1",
  "evaluator_pinned": true,
  "artifact_hashes": {
    "baseline": {},
    "candidate": {}
  }
}
```
