## Arisole Robot Reliability Gate (`BLOCK`)

- Suite: `arisole-eval-lerobot-v0.1` v`0.1.5`
- Gate engine: `deployment-gate-v1`
- Config: `arisole-reliability-ci-v1`
- Suite status: `cannot_compare`

### Reasons
- **BLOCK** · `block_on_incompatible` — Cannot compare runs: required identity fields are missing and could not be inferred from eval_info.json without inventing values.
  baseline (/Users/danielwahnich/workspace/nisayon-codex/artifacts/n038-2026-10-15/final/suite_missing/baseline): missing task, environment
  candidate (/Users/danielwahnich/workspace/nisayon-codex/artifacts/n038-2026-10-15/final/suite_missing/candidate): missing task, environment
Provide a run_meta.json beside each eval_info.json, or pass explicit flags, e.g.:
  arisole evaluate --baseline A --candidate B \
    --task <suite_or_task> --environment <env_name> \
    --baseline-checkpoint <id> --candidate-checkpoint <id>
Checkpoint IDs are optional for local compare; task and environment are required for a valid match. Episode pairing still requires shared per-episode seeds.

### Transitions
- Matched (shared seeds): 0
- Comparable (fully labelled): 0
- Incomparable / unknown labels: 0
- P2F: 0 · F2P: 0 · F2F: 0 · P2P: 0

### Honesty
- Missing success labels or weak n never become PASS.
- Regression rates use labelled pairs only; INCOMPARABLE rows stay unknown.
- Trajectory metrics remain `insufficient_data` when channels are absent.
- Secrets must never appear in this summary.

### Reproducibility
```json
{
  "suite_id": "arisole-eval-lerobot-v0.1",
  "suite_version": "0.1.5",
  "gate_engine_version": "deployment-gate-v1",
  "config_version": "arisole-reliability-ci-v1",
  "evaluator_pinned": true,
  "artifact_hashes": {
    "baseline": {},
    "candidate": {}
  }
}
```
